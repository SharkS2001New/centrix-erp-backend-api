-- MySQL dump 10.13  Distrib 9.6.0, for macos14.8 (x86_64)
--
-- Host: 127.0.0.1    Database: pos_erp
-- ------------------------------------------------------
-- Server version	9.6.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '27eb38b8-5e05-11f1-9be3-588ebe0e0d16:1-1203684';

--
-- Table structure for table `accounting_account_mappings`
--

DROP TABLE IF EXISTS `accounting_account_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_account_mappings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `provider` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_account_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `external_account_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `external_account_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_provider_local_account` (`organization_id`,`provider`,`local_account_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_account_mappings`
--

LOCK TABLES `accounting_account_mappings` WRITE;
/*!40000 ALTER TABLE `accounting_account_mappings` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_account_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting_connections`
--

DROP TABLE IF EXISTS `accounting_connections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_connections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `provider` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `realm_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_token` text COLLATE utf8mb4_unicode_ci,
  `refresh_token` text COLLATE utf8mb4_unicode_ci,
  `token_expires_at` timestamp NULL DEFAULT NULL,
  `status` enum('disconnected','connected','error') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'disconnected',
  `last_error` text COLLATE utf8mb4_unicode_ci,
  `connected_at` timestamp NULL DEFAULT NULL,
  `connected_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_accounting_provider` (`organization_id`,`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_connections`
--

LOCK TABLES `accounting_connections` WRITE;
/*!40000 ALTER TABLE `accounting_connections` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_connections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting_export_queue`
--

DROP TABLE IF EXISTS `accounting_export_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_export_queue` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `provider` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_date` date NOT NULL,
  `reference_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` bigint unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lines` json NOT NULL,
  `status` enum('pending','exported','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `external_journal_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_error` text COLLATE utf8mb4_unicode_ci,
  `exported_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_provider_export_ref` (`organization_id`,`provider`,`reference_type`,`reference_id`),
  KEY `accounting_export_queue_organization_id_status_index` (`organization_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_export_queue`
--

LOCK TABLES `accounting_export_queue` WRITE;
/*!40000 ALTER TABLE `accounting_export_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_export_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_knowledge_entries`
--

DROP TABLE IF EXISTS `ai_knowledge_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_knowledge_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `created_by` int DEFAULT NULL,
  `source` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `confirmed_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ai_knowledge_entries_organization_id_confirmed_index` (`organization_id`,`confirmed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_knowledge_entries`
--

LOCK TABLES `ai_knowledge_entries` WRITE;
/*!40000 ALTER TABLE `ai_knowledge_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `ai_knowledge_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_clock_devices`
--

DROP TABLE IF EXISTS `attendance_clock_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance_clock_devices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `device_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_clock_device` (`organization_id`,`device_no`),
  CONSTRAINT `attendance_clock_devices_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_clock_devices`
--

LOCK TABLES `attendance_clock_devices` WRITE;
/*!40000 ALTER TABLE `attendance_clock_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendance_clock_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `record_id` varchar(100) NOT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_table_name` (`table_name`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `audit_logs_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,1,'create','products','6161100100015',NULL,'{\"product_name\": \"Mumias White Sugar 50kg\", \"selling_price\": 125}','127.0.0.1','DemoDataSeeder','2026-06-17 14:25:21'),(2,1,1,'update','products','6161100100015','{\"selling_price\": 120}','{\"selling_price\": 125}','127.0.0.1','DemoDataSeeder','2026-06-18 14:25:21'),(3,2,1,'create','sales','1',NULL,'{\"status\": \"completed\", \"order_num\": 1, \"order_total\": 1250}','10.0.0.12','POS Terminal','2026-06-19 14:25:21'),(4,1,1,'update','users','2','{\"is_active\": false}','{\"is_active\": true}','127.0.0.1','Mozilla/5.0','2026-06-20 08:25:21');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `branch_code` varchar(45) NOT NULL,
  `branch_name` varchar(200) NOT NULL,
  `branch_address` varchar(400) DEFAULT NULL,
  `branch_phone` varchar(45) DEFAULT NULL,
  `branch_email` varchar(200) DEFAULT NULL,
  `branch_type` enum('supermarket','wholesale','retail','distribution','small_shop') NOT NULL DEFAULT 'retail',
  `is_active` tinyint(1) DEFAULT '1',
  `settings` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_branch_code` (`organization_id`,`branch_code`),
  KEY `idx_branch_type` (`branch_type`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `branches_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES (1,1,'HQ','Head Office',NULL,'0700111222',NULL,'supermarket',1,'{\"stock_alert_mode\": \"both\", \"global_low_stock_threshold\": 5}','2026-06-20 14:25:19','2026-06-20 14:25:19'),(2,2,'HQ','Platform HQ',NULL,'0700000000',NULL,'supermarket',1,NULL,'2026-06-20 14:25:21','2026-06-20 14:25:21');
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_lines`
--

DROP TABLE IF EXISTS `cart_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_lines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cart_id` int NOT NULL,
  `update_code` varchar(24) NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `product_name` varchar(250) DEFAULT NULL,
  `unit_price` double DEFAULT NULL,
  `quantity` float DEFAULT NULL,
  `uom` varchar(45) DEFAULT NULL,
  `product_vat` double DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `discount_given` double NOT NULL DEFAULT '0',
  `on_wholesale_retail` int DEFAULT '0',
  `line_no` int DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cart_line_update_code` (`update_code`),
  KEY `idx_cart_id` (`cart_id`),
  CONSTRAINT `cart_lines_ibfk_1` FOREIGN KEY (`cart_id`) REFERENCES `temporary_carts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_lines`
--

LOCK TABLES `cart_lines` WRITE;
/*!40000 ALTER TABLE `cart_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Food & Beverage',1,'2026-06-20 14:25:21','2026-06-20 14:25:21');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart_of_accounts`
--

DROP TABLE IF EXISTS `chart_of_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chart_of_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `account_code` varchar(20) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `account_type` enum('asset','liability','equity','revenue','expense') NOT NULL,
  `parent_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_account` (`organization_id`,`account_code`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `chart_of_accounts_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `chart_of_accounts_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `chart_of_accounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart_of_accounts`
--

LOCK TABLES `chart_of_accounts` WRITE;
/*!40000 ALTER TABLE `chart_of_accounts` DISABLE KEYS */;
INSERT INTO `chart_of_accounts` VALUES (1,1,'1000','Cash','asset',NULL,1,'2026-06-20 17:25:21'),(2,1,'1100','Bank Account','asset',NULL,1,'2026-06-20 17:25:21'),(3,1,'1200','Accounts Receivable','asset',NULL,1,'2026-06-20 17:25:21'),(4,1,'1300','Inventory','asset',NULL,1,'2026-06-20 17:25:21'),(5,1,'2100','VAT Payable','liability',NULL,1,'2026-06-20 17:25:21'),(6,1,'2000','Accounts Payable','liability',NULL,1,'2026-06-20 17:25:21'),(7,1,'3000','Owner Equity','equity',NULL,1,'2026-06-20 17:25:21'),(8,1,'3100','Retained Earnings','equity',NULL,1,'2026-06-20 17:25:21'),(9,1,'4000','Sales Revenue','revenue',NULL,1,'2026-06-20 17:25:21'),(10,1,'5000','Cost of Goods Sold','expense',NULL,1,'2026-06-20 17:25:21'),(11,1,'5100','Cash Over / Short','expense',NULL,1,'2026-06-20 17:25:21'),(12,1,'5200','Payroll Expense','expense',NULL,1,'2026-06-20 17:25:21'),(13,1,'5300','Operating Expenses','expense',NULL,1,'2026-06-20 17:25:21');
/*!40000 ALTER TABLE `chart_of_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_notes`
--

DROP TABLE IF EXISTS `credit_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_notes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `credit_note_no` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_return_id` bigint unsigned NOT NULL,
  `organization_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `sale_id` bigint DEFAULT NULL,
  `customer_num` int DEFAULT NULL,
  `credit_date` date NOT NULL,
  `total_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `refund_method` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CASH',
  `reason` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `kra_status` enum('skipped','pending','success','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'skipped',
  `kra_relevant_invoice_number` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kra_refund_reason_code` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kra_invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kra_cu_inv_no` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kra_receipt_signature` text COLLATE utf8mb4_unicode_ci,
  `kra_signature_link` text COLLATE utf8mb4_unicode_ci,
  `kra_serial_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kra_timestamp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kra_request_payload` json DEFAULT NULL,
  `kra_response_payload` json DEFAULT NULL,
  `kra_error_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `credit_notes_credit_note_no_unique` (`credit_note_no`),
  UNIQUE KEY `credit_notes_customer_return_id_unique` (`customer_return_id`),
  KEY `credit_notes_branch_id_foreign` (`branch_id`),
  KEY `credit_notes_sale_id_foreign` (`sale_id`),
  KEY `credit_notes_customer_num_foreign` (`customer_num`),
  KEY `credit_notes_organization_id_credit_date_index` (`organization_id`,`credit_date`),
  CONSTRAINT `credit_notes_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `credit_notes_customer_num_foreign` FOREIGN KEY (`customer_num`) REFERENCES `customers` (`customer_num`),
  CONSTRAINT `credit_notes_customer_return_id_foreign` FOREIGN KEY (`customer_return_id`) REFERENCES `customer_returns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `credit_notes_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `credit_notes_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_notes`
--

LOCK TABLES `credit_notes` WRITE;
/*!40000 ALTER TABLE `credit_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `current_stock`
--

DROP TABLE IF EXISTS `current_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `current_stock` (
  `product_code` varchar(200) NOT NULL,
  `branch_id` int NOT NULL,
  `shop_quantity` float NOT NULL DEFAULT '0',
  `store_quantity` float NOT NULL DEFAULT '0',
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`product_code`,`branch_id`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `current_stock_ibfk_1` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`),
  CONSTRAINT `current_stock_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `current_stock`
--

LOCK TABLES `current_stock` WRITE;
/*!40000 ALTER TABLE `current_stock` DISABLE KEYS */;
INSERT INTO `current_stock` VALUES ('6161100100015',1,2500,5000,'2026-06-20 17:25:21');
/*!40000 ALTER TABLE `current_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_report_templates`
--

DROP TABLE IF EXISTS `custom_report_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_report_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `created_by` int NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `spec` json NOT NULL,
  `is_shared` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_report_templates_created_by_foreign` (`created_by`),
  KEY `custom_report_templates_organization_id_is_shared_index` (`organization_id`,`is_shared`),
  CONSTRAINT `custom_report_templates_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `custom_report_templates_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_report_templates`
--

LOCK TABLES `custom_report_templates` WRITE;
/*!40000 ALTER TABLE `custom_report_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_report_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_invoice_payments`
--

DROP TABLE IF EXISTS `customer_invoice_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_invoice_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_invoice_id` bigint NOT NULL,
  `customer_num` int NOT NULL,
  `payment_method_id` int NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `amount_due_snapshot` decimal(10,2) DEFAULT NULL,
  `cheque_number` varchar(45) DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `date_paid` date NOT NULL,
  `received_by` int NOT NULL,
  `organization_id` int NOT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `customer_num` (`customer_num`),
  KEY `payment_method_id` (`payment_method_id`),
  KEY `received_by` (`received_by`),
  KEY `organization_id` (`organization_id`),
  KEY `idx_customer_invoice_id` (`customer_invoice_id`),
  KEY `idx_date_paid` (`date_paid`),
  CONSTRAINT `customer_invoice_payments_ibfk_1` FOREIGN KEY (`customer_invoice_id`) REFERENCES `customer_invoices` (`id`),
  CONSTRAINT `customer_invoice_payments_ibfk_2` FOREIGN KEY (`customer_num`) REFERENCES `customers` (`customer_num`),
  CONSTRAINT `customer_invoice_payments_ibfk_3` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`),
  CONSTRAINT `customer_invoice_payments_ibfk_4` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`),
  CONSTRAINT `customer_invoice_payments_ibfk_5` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_invoice_payments`
--

LOCK TABLES `customer_invoice_payments` WRITE;
/*!40000 ALTER TABLE `customer_invoice_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_invoice_payments` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`steve`@`localhost`*/ /*!50003 TRIGGER `trg_update_ar_on_payment` AFTER INSERT ON `customer_invoice_payments` FOR EACH ROW BEGIN
    DECLARE new_paid DECIMAL(10,2);
    DECLARE inv_total DECIMAL(10,2);

    SELECT (amount_paid + NEW.amount_paid), invoice_total
    INTO new_paid, inv_total
    FROM customer_invoices WHERE id = NEW.customer_invoice_id;

    UPDATE customer_invoices
    SET amount_paid    = new_paid,
        payment_status = CASE
            WHEN new_paid >= inv_total THEN 2
            WHEN new_paid > 0         THEN 1
            ELSE 0
        END,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = NEW.customer_invoice_id;

    UPDATE customers
    SET current_balance = (
        SELECT COALESCE(SUM(balance_due), 0)
        FROM customer_invoices
        WHERE customer_num = NEW.customer_num
          AND payment_status IN (0,1)
          AND deleted_at IS NULL
    )
    WHERE customer_num = NEW.customer_num;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `customer_invoices`
--

DROP TABLE IF EXISTS `customer_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_invoices` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `sale_id` bigint NOT NULL,
  `customer_num` int NOT NULL,
  `branch_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `created_by` int NOT NULL,
  `invoice_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `total_vat` float NOT NULL DEFAULT '0',
  `invoice_total` decimal(10,2) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance_due` decimal(10,2) GENERATED ALWAYS AS ((`invoice_total` - `amount_paid`)) STORED,
  `payment_status` tinyint NOT NULL DEFAULT '0',
  `notes` text,
  `deleted_by` int DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `sale_id` (`sale_id`),
  KEY `branch_id` (`branch_id`),
  KEY `organization_id` (`organization_id`),
  KEY `created_by` (`created_by`),
  KEY `deleted_by` (`deleted_by`),
  KEY `idx_customer_num` (`customer_num`),
  KEY `idx_payment_status` (`payment_status`),
  KEY `idx_invoice_date` (`invoice_date`),
  CONSTRAINT `customer_invoices_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
  CONSTRAINT `customer_invoices_ibfk_2` FOREIGN KEY (`customer_num`) REFERENCES `customers` (`customer_num`),
  CONSTRAINT `customer_invoices_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `customer_invoices_ibfk_4` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `customer_invoices_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `customer_invoices_ibfk_6` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_invoices`
--

LOCK TABLES `customer_invoices` WRITE;
/*!40000 ALTER TABLE `customer_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_return_lines`
--

DROP TABLE IF EXISTS `customer_return_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_return_lines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_return_id` bigint unsigned NOT NULL,
  `sale_item_id` bigint DEFAULT NULL,
  `product_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uom` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity_sold` double NOT NULL DEFAULT '0',
  `return_qty` double NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `line_no` smallint unsigned DEFAULT NULL,
  `legacy_return_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_return_lines_customer_return_id_foreign` (`customer_return_id`),
  KEY `customer_return_lines_product_code_index` (`product_code`),
  KEY `customer_return_lines_legacy_return_id_index` (`legacy_return_id`),
  CONSTRAINT `customer_return_lines_customer_return_id_foreign` FOREIGN KEY (`customer_return_id`) REFERENCES `customer_returns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_return_lines`
--

LOCK TABLES `customer_return_lines` WRITE;
/*!40000 ALTER TABLE `customer_return_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_return_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_returns`
--

DROP TABLE IF EXISTS `customer_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_returns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `return_no` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `sale_id` bigint DEFAULT NULL,
  `customer_num` int DEFAULT NULL,
  `return_date` date NOT NULL,
  `refund_method` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CASH',
  `reason` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `total_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `stock_location` enum('shop','store') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'shop',
  `returned_by` int NOT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejected_by` int DEFAULT NULL,
  `rejected_at` timestamp NULL DEFAULT NULL,
  `reject_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_returns_return_no_unique` (`return_no`),
  KEY `customer_returns_branch_id_foreign` (`branch_id`),
  KEY `customer_returns_sale_id_foreign` (`sale_id`),
  KEY `customer_returns_customer_num_foreign` (`customer_num`),
  KEY `customer_returns_returned_by_foreign` (`returned_by`),
  KEY `customer_returns_approved_by_foreign` (`approved_by`),
  KEY `customer_returns_rejected_by_foreign` (`rejected_by`),
  KEY `customer_returns_organization_id_status_index` (`organization_id`,`status`),
  KEY `customer_returns_return_date_index` (`return_date`),
  CONSTRAINT `customer_returns_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `customer_returns_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `customer_returns_customer_num_foreign` FOREIGN KEY (`customer_num`) REFERENCES `customers` (`customer_num`),
  CONSTRAINT `customer_returns_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `customer_returns_rejected_by_foreign` FOREIGN KEY (`rejected_by`) REFERENCES `users` (`id`),
  CONSTRAINT `customer_returns_returned_by_foreign` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`),
  CONSTRAINT `customer_returns_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_returns`
--

LOCK TABLES `customer_returns` WRITE;
/*!40000 ALTER TABLE `customer_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `customer_num` int NOT NULL,
  `branch_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `customer_type` enum('debtor','route','regular') NOT NULL DEFAULT 'debtor',
  `phone_number` varchar(45) DEFAULT NULL,
  `additional_phone` varchar(45) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `town` varchar(200) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `shop_image` varchar(255) DEFAULT NULL,
  `route_id` int DEFAULT NULL,
  `created_by` int NOT NULL,
  `customer_status` int DEFAULT '0',
  `kra_pin` varchar(45) DEFAULT NULL,
  `terms_of_payment` varchar(45) DEFAULT NULL,
  `credit_limit` decimal(10,2) DEFAULT '0.00',
  `current_balance` decimal(10,2) DEFAULT '0.00',
  `deleted_by` int DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_num`),
  KEY `organization_id` (`organization_id`),
  KEY `created_by` (`created_by`),
  KEY `deleted_by` (`deleted_by`),
  KEY `idx_phone` (`phone_number`),
  KEY `idx_branch_id` (`branch_id`),
  KEY `idx_route_id` (`route_id`),
  KEY `idx_customer_type` (`customer_type`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `customers_ibfk_2` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `customers_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `customers_ibfk_5` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  CONSTRAINT `customers_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (5002,1,1,'Eastlands Mini Mart','route','0722111222',NULL,NULL,NULL,NULL,NULL,NULL,1,1,0,NULL,NULL,50000.00,0.00,NULL,NULL,'2026-06-20 14:25:21','2026-06-20 14:25:21');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `damages`
--

DROP TABLE IF EXISTS `damages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `damages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_code` varchar(200) NOT NULL,
  `branch_id` int NOT NULL,
  `quantity` double NOT NULL,
  `package_type` enum('full_package','partial','pieces') NOT NULL DEFAULT 'partial',
  `uom_label` varchar(45) DEFAULT NULL,
  `stock_location` enum('shop','store') NOT NULL DEFAULT 'shop',
  `reason` text,
  `reported_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `reported_by` (`reported_by`),
  KEY `idx_product_code` (`product_code`),
  CONSTRAINT `damages_ibfk_1` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`),
  CONSTRAINT `damages_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `damages_ibfk_3` FOREIGN KEY (`reported_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `damages`
--

LOCK TABLES `damages` WRITE;
/*!40000 ALTER TABLE `damages` DISABLE KEYS */;
/*!40000 ALTER TABLE `damages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `department_code` varchar(45) NOT NULL,
  `department_name` varchar(200) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_dept` (`organization_id`,`department_code`),
  CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,1,'SALES','Sales',1);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dispatch_trip_sales`
--

DROP TABLE IF EXISTS `dispatch_trip_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispatch_trip_sales` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `trip_id` bigint NOT NULL,
  `sale_id` bigint NOT NULL,
  `stop_seq` smallint unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_trip_sale` (`trip_id`,`sale_id`),
  KEY `idx_sale_id` (`sale_id`),
  CONSTRAINT `dispatch_trip_sales_ibfk_1` FOREIGN KEY (`trip_id`) REFERENCES `dispatch_trips` (`id`) ON DELETE CASCADE,
  CONSTRAINT `dispatch_trip_sales_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispatch_trip_sales`
--

LOCK TABLES `dispatch_trip_sales` WRITE;
/*!40000 ALTER TABLE `dispatch_trip_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispatch_trip_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dispatch_trips`
--

DROP TABLE IF EXISTS `dispatch_trips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispatch_trips` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `trip_code` varchar(50) NOT NULL,
  `route_id` int DEFAULT NULL,
  `driver_id` int DEFAULT NULL,
  `vehicle_id` int DEFAULT NULL,
  `scheduled_date` date NOT NULL,
  `status` enum('draft','loading','in_transit','completed','cancelled') NOT NULL DEFAULT 'draft',
  `notes` text,
  `expected_cash` decimal(14,2) DEFAULT NULL,
  `collected_cash` decimal(14,2) DEFAULT NULL,
  `cash_variance` decimal(14,2) DEFAULT NULL,
  `prepared_by_name` varchar(200) DEFAULT NULL,
  `prepared_at` timestamp NULL DEFAULT NULL,
  `checked_by_name` varchar(200) DEFAULT NULL,
  `checked_at` timestamp NULL DEFAULT NULL,
  `departed_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `settled_at` timestamp NULL DEFAULT NULL,
  `settled_by` int DEFAULT NULL,
  `stock_deducted_at` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_branch_trip_code` (`branch_id`,`trip_code`),
  KEY `driver_id` (`driver_id`),
  KEY `vehicle_id` (`vehicle_id`),
  KEY `settled_by` (`settled_by`),
  KEY `created_by` (`created_by`),
  KEY `idx_branch_date_status` (`branch_id`,`scheduled_date`,`status`),
  KEY `idx_route_date` (`route_id`,`scheduled_date`),
  CONSTRAINT `dispatch_trips_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `dispatch_trips_ibfk_2` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `dispatch_trips_ibfk_3` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `dispatch_trips_ibfk_4` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `dispatch_trips_ibfk_5` FOREIGN KEY (`settled_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `dispatch_trips_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispatch_trips`
--

LOCK TABLES `dispatch_trips` WRITE;
/*!40000 ALTER TABLE `dispatch_trips` DISABLE KEYS */;
/*!40000 ALTER TABLE `dispatch_trips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drivers`
--

DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drivers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `default_vehicle_id` int DEFAULT NULL,
  `default_route_id` int DEFAULT NULL,
  `driver_code` varchar(45) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_branch_driver` (`branch_id`,`driver_code`),
  KEY `user_id` (`user_id`),
  KEY `idx_default_vehicle` (`default_vehicle_id`),
  KEY `idx_default_route` (`default_route_id`),
  CONSTRAINT `drivers_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `drivers_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `drivers_ibfk_3` FOREIGN KEY (`default_vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `drivers_ibfk_4` FOREIGN KEY (`default_route_id`) REFERENCES `routes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drivers`
--

LOCK TABLES `drivers` WRITE;
/*!40000 ALTER TABLE `drivers` DISABLE KEYS */;
INSERT INTO `drivers` VALUES (1,1,NULL,1,1,'JK-001','John Kamau','0712345678',1,'2026-06-20 17:25:21');
/*!40000 ALTER TABLE `drivers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_allowances`
--

DROP TABLE IF EXISTS `employee_allowances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_allowances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `notes` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `employee_allowances_organization_id_foreign` (`organization_id`),
  KEY `employee_allowances_employee_id_is_active_index` (`employee_id`,`is_active`),
  CONSTRAINT `employee_allowances_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_allowances_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_allowances`
--

LOCK TABLES `employee_allowances` WRITE;
/*!40000 ALTER TABLE `employee_allowances` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_allowances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_attendance`
--

DROP TABLE IF EXISTS `employee_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_attendance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `attendance_date` date NOT NULL,
  `check_in` time DEFAULT NULL,
  `check_out` time DEFAULT NULL,
  `status` enum('present','absent','late','half_day','leave','holiday') NOT NULL DEFAULT 'present',
  `source` enum('manual','clock_device') NOT NULL DEFAULT 'manual',
  `device_identifier` varchar(100) DEFAULT NULL,
  `hours_worked` decimal(5,2) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `payroll_run_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_emp_attendance_date` (`employee_id`,`attendance_date`),
  KEY `branch_id` (`branch_id`),
  KEY `idx_att_org_date` (`organization_id`,`attendance_date`),
  KEY `employee_attendance_payroll_run_id_foreign` (`payroll_run_id`),
  CONSTRAINT `employee_attendance_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_attendance_ibfk_2` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `employee_attendance_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employee_attendance_payroll_run_id_foreign` FOREIGN KEY (`payroll_run_id`) REFERENCES `payroll_runs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_attendance`
--

LOCK TABLES `employee_attendance` WRITE;
/*!40000 ALTER TABLE `employee_attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_bank_accounts`
--

DROP TABLE IF EXISTS `employee_bank_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_bank_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `bank_branch` varchar(200) DEFAULT NULL,
  `account_number` varchar(45) NOT NULL,
  `account_name` varchar(200) NOT NULL,
  `payment_method` enum('bank_transfer','mpesa','cash','cheque') DEFAULT 'bank_transfer',
  `is_primary` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_emp_bank` (`employee_id`),
  CONSTRAINT `employee_bank_accounts_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_bank_accounts`
--

LOCK TABLES `employee_bank_accounts` WRITE;
/*!40000 ALTER TABLE `employee_bank_accounts` DISABLE KEYS */;
INSERT INTO `employee_bank_accounts` VALUES (1,1,'KCB Bank','Westlands','1234567890','System Administrator','bank_transfer',1,'2026-06-20 17:25:20');
/*!40000 ALTER TABLE `employee_bank_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_cash_advances`
--

DROP TABLE IF EXISTS `employee_cash_advances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_cash_advances` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `advance_date` date NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `balance` decimal(12,2) NOT NULL,
  `status` enum('open','repaid','cancelled') NOT NULL DEFAULT 'open',
  `repayment_mode` enum('full_next_cycle','fixed_per_cycle') NOT NULL DEFAULT 'fixed_per_cycle',
  `repayment_amount` decimal(12,2) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `organization_id` (`organization_id`),
  KEY `idx_adv_emp` (`employee_id`),
  CONSTRAINT `employee_cash_advances_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_cash_advances_ibfk_2` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_cash_advances`
--

LOCK TABLES `employee_cash_advances` WRITE;
/*!40000 ALTER TABLE `employee_cash_advances` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_cash_advances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_clock_sessions`
--

DROP TABLE IF EXISTS `employee_clock_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_clock_sessions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `clock_in_at` datetime NOT NULL,
  `clock_out_at` datetime DEFAULT NULL,
  `device_identifier` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attendance_id` int DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `employee_clock_sessions_organization_id_foreign` (`organization_id`),
  KEY `employee_clock_sessions_branch_id_foreign` (`branch_id`),
  KEY `employee_clock_sessions_attendance_id_foreign` (`attendance_id`),
  KEY `idx_clock_open` (`employee_id`,`clock_out_at`),
  CONSTRAINT `employee_clock_sessions_attendance_id_foreign` FOREIGN KEY (`attendance_id`) REFERENCES `employee_attendance` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employee_clock_sessions_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employee_clock_sessions_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_clock_sessions_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_clock_sessions`
--

LOCK TABLES `employee_clock_sessions` WRITE;
/*!40000 ALTER TABLE `employee_clock_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_clock_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_deductions`
--

DROP TABLE IF EXISTS `employee_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_deductions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `deduction_type_id` int DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `calc_type` enum('fixed','percentage') NOT NULL DEFAULT 'fixed',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `percentage` decimal(5,2) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `notes` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `deduction_type_id` (`deduction_type_id`),
  KEY `idx_emp_deduction` (`employee_id`),
  CONSTRAINT `employee_deductions_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_deductions_ibfk_2` FOREIGN KEY (`deduction_type_id`) REFERENCES `payroll_deduction_types` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_deductions`
--

LOCK TABLES `employee_deductions` WRITE;
/*!40000 ALTER TABLE `employee_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_deductions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_documents`
--

DROP TABLE IF EXISTS `employee_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `document_type` enum('contract','national_id','passport','kra_pin','offer_letter','certificate','other') NOT NULL DEFAULT 'other',
  `title` varchar(200) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `file_size` int DEFAULT NULL,
  `uploaded_by` int DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `idx_emp_doc` (`employee_id`),
  CONSTRAINT `employee_documents_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_documents_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_documents`
--

LOCK TABLES `employee_documents` WRITE;
/*!40000 ALTER TABLE `employee_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_emergency_contacts`
--

DROP TABLE IF EXISTS `employee_emergency_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_emergency_contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `phone` varchar(45) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `is_primary` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_emp_emergency` (`employee_id`),
  CONSTRAINT `employee_emergency_contacts_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_emergency_contacts`
--

LOCK TABLES `employee_emergency_contacts` WRITE;
/*!40000 ALTER TABLE `employee_emergency_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_emergency_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_kpis`
--

DROP TABLE IF EXISTS `employee_kpis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_kpis` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `organization_kpi_id` bigint unsigned DEFAULT NULL,
  `kpi_code` varchar(64) DEFAULT NULL,
  `label` varchar(200) NOT NULL,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `target_value` decimal(12,2) DEFAULT NULL,
  `actual_value` decimal(12,2) DEFAULT NULL,
  `unit` varchar(32) DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kpi_employee_period` (`employee_id`,`period_start`),
  KEY `idx_kpi_org` (`organization_id`),
  KEY `employee_kpis_organization_kpi_id_employee_id_index` (`organization_kpi_id`,`employee_id`),
  CONSTRAINT `employee_kpis_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_kpis_ibfk_2` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `employee_kpis_organization_kpi_id_foreign` FOREIGN KEY (`organization_kpi_id`) REFERENCES `organization_kpis` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_kpis`
--

LOCK TABLES `employee_kpis` WRITE;
/*!40000 ALTER TABLE `employee_kpis` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_kpis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_leave_balances`
--

DROP TABLE IF EXISTS `employee_leave_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_leave_balances` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `off_days_allocated` decimal(6,2) NOT NULL DEFAULT '0.00',
  `annual_adjustment` decimal(6,2) NOT NULL DEFAULT '0.00',
  `sick_adjustment` decimal(6,2) NOT NULL DEFAULT '0.00',
  `notes` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_leave_balances_employee_id_unique` (`employee_id`),
  KEY `employee_leave_balances_organization_id_foreign` (`organization_id`),
  CONSTRAINT `employee_leave_balances_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_leave_balances_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_leave_balances`
--

LOCK TABLES `employee_leave_balances` WRITE;
/*!40000 ALTER TABLE `employee_leave_balances` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_leave_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_leave_days`
--

DROP TABLE IF EXISTS `employee_leave_days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_leave_days` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `leave_type` enum('annual','sick','unpaid','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'annual',
  `assignment_kind` enum('leave','off_day') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'leave',
  `deduct_from` enum('annual','sick','off_days','unpaid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'annual',
  `duration_type` enum('full_day','half_day') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full_day',
  `half_day_period` enum('morning','afternoon') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_days` decimal(6,2) NOT NULL DEFAULT '1.00',
  `days_deducted` decimal(6,2) NOT NULL DEFAULT '0.00',
  `total_hours` decimal(6,2) DEFAULT NULL,
  `notes` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approval_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'approved',
  `payroll_run_id` int DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_emp_leave_date` (`employee_id`),
  KEY `employee_leave_days_organization_id_foreign` (`organization_id`),
  KEY `employee_leave_days_payroll_run_id_foreign` (`payroll_run_id`),
  CONSTRAINT `employee_leave_days_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_leave_days_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `employee_leave_days_payroll_run_id_foreign` FOREIGN KEY (`payroll_run_id`) REFERENCES `payroll_runs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_leave_days`
--

LOCK TABLES `employee_leave_days` WRITE;
/*!40000 ALTER TABLE `employee_leave_days` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_leave_days` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_next_of_kin`
--

DROP TABLE IF EXISTS `employee_next_of_kin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_next_of_kin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `national_id` varchar(45) DEFAULT NULL,
  `phone` varchar(45) NOT NULL,
  `address` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_employee_nok` (`employee_id`),
  CONSTRAINT `employee_next_of_kin_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_next_of_kin`
--

LOCK TABLES `employee_next_of_kin` WRITE;
/*!40000 ALTER TABLE `employee_next_of_kin` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_next_of_kin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_overtime`
--

DROP TABLE IF EXISTS `employee_overtime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_overtime` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `work_date` date NOT NULL,
  `hours` decimal(6,2) NOT NULL DEFAULT '0.00',
  `rate_mode` varchar(20) NOT NULL DEFAULT 'from_salary',
  `hourly_rate` decimal(12,2) DEFAULT NULL,
  `rate_multiplier` decimal(4,2) NOT NULL DEFAULT '1.50',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` enum('pending','approved','paid','rejected') NOT NULL DEFAULT 'pending',
  `pay_period_id` int DEFAULT NULL,
  `payroll_run_id` int DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `organization_id` (`organization_id`),
  KEY `pay_period_id` (`pay_period_id`),
  KEY `idx_ot_emp_date` (`employee_id`,`work_date`),
  KEY `employee_overtime_payroll_run_id_foreign` (`payroll_run_id`),
  CONSTRAINT `employee_overtime_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_overtime_ibfk_2` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `employee_overtime_ibfk_3` FOREIGN KEY (`pay_period_id`) REFERENCES `pay_periods` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employee_overtime_payroll_run_id_foreign` FOREIGN KEY (`payroll_run_id`) REFERENCES `payroll_runs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_overtime`
--

LOCK TABLES `employee_overtime` WRITE;
/*!40000 ALTER TABLE `employee_overtime` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_overtime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `position_id` int DEFAULT NULL,
  `shift_id` int unsigned DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `reports_to_employee_id` int DEFAULT NULL,
  `employee_code` varchar(45) NOT NULL,
  `payroll_number` varchar(45) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `full_name` varchar(200) NOT NULL,
  `gender` enum('male','female','other','undisclosed') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `national_id` varchar(45) DEFAULT NULL,
  `id_document_type` enum('national_id','passport') DEFAULT 'national_id',
  `marital_status` enum('single','married','divorced','widowed','other') DEFAULT NULL,
  `personal_email` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `alt_phone` varchar(45) DEFAULT NULL,
  `physical_address` varchar(500) DEFAULT NULL,
  `postal_address` varchar(500) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `county` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'Kenya',
  `photo_path` varchar(500) DEFAULT NULL,
  `employment_status` enum('active','suspended','terminated','retired') DEFAULT 'active',
  `employment_type` enum('permanent','contract','casual','intern') DEFAULT 'permanent',
  `job_title` varchar(100) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `confirmation_date` date DEFAULT NULL,
  `probation_end_date` date DEFAULT NULL,
  `contract_start_date` date DEFAULT NULL,
  `contract_end_date` date DEFAULT NULL,
  `notice_period_days` int DEFAULT NULL,
  `pay_frequency` enum('monthly','biweekly','weekly') DEFAULT 'monthly',
  `base_salary` decimal(12,2) DEFAULT '0.00',
  `monthly_allowance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `kra_pin` varchar(45) DEFAULT NULL,
  `nssf_number` varchar(45) DEFAULT NULL,
  `sha_number` varchar(45) DEFAULT NULL,
  `housing_levy_number` varchar(45) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_employee` (`organization_id`,`employee_code`),
  KEY `user_id` (`user_id`),
  KEY `idx_emp_branch` (`branch_id`),
  KEY `idx_emp_dept` (`department_id`),
  KEY `idx_emp_position` (`position_id`),
  KEY `idx_emp_reports_to` (`reports_to_employee_id`),
  KEY `employees_shift_id_foreign` (`shift_id`),
  CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `employees_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `employees_ibfk_3` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `employees_ibfk_4` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_ibfk_5` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `employees_ibfk_6` FOREIGN KEY (`reports_to_employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL,
  CONSTRAINT `employees_shift_id_foreign` FOREIGN KEY (`shift_id`) REFERENCES `work_shifts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,1,1,1,1,NULL,1,NULL,'EMP#0001','EMP#0001','System',NULL,'Administrator','System Administrator',NULL,NULL,NULL,NULL,'national_id',NULL,NULL,'admin@demo.co.ke','0700111222',NULL,NULL,NULL,NULL,NULL,'Kenya',NULL,'active','permanent','General Manager','2024-06-20',NULL,NULL,NULL,NULL,NULL,'monthly',85000.00,0.00,'A001234567Z',NULL,NULL,NULL,1,'2026-06-20 17:25:20');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense_groups`
--

DROP TABLE IF EXISTS `expense_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expense_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_name` (`group_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_groups`
--

LOCK TABLES `expense_groups` WRITE;
/*!40000 ALTER TABLE `expense_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `expense_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `expense_group_id` int NOT NULL,
  `float_session_id` bigint DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `expense_amount` decimal(10,0) DEFAULT NULL,
  `expense_date` date NOT NULL,
  `balance_due` varchar(45) DEFAULT NULL,
  `invoice_no` varchar(45) DEFAULT NULL,
  `receipt_image` mediumblob,
  `billable_status` int DEFAULT '1',
  `payment_method_id` int NOT NULL,
  `recorded_by` int NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expense_group_id` (`expense_group_id`),
  KEY `float_session_id` (`float_session_id`),
  KEY `payment_method_id` (`payment_method_id`),
  KEY `recorded_by` (`recorded_by`),
  KEY `deleted_by` (`deleted_by`),
  KEY `idx_branch_id` (`branch_id`),
  KEY `idx_expense_date` (`expense_date`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `expenses_ibfk_2` FOREIGN KEY (`expense_group_id`) REFERENCES `expense_groups` (`id`),
  CONSTRAINT `expenses_ibfk_3` FOREIGN KEY (`float_session_id`) REFERENCES `till_float_sessions` (`id`),
  CONSTRAINT `expenses_ibfk_4` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`),
  CONSTRAINT `expenses_ibfk_5` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`),
  CONSTRAINT `expenses_ibfk_6` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fiscal_periods`
--

DROP TABLE IF EXISTS `fiscal_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fiscal_periods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `period_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('open','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `closed_at` timestamp NULL DEFAULT NULL,
  `closed_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_fiscal_start` (`organization_id`,`start_date`),
  KEY `fiscal_periods_organization_id_status_index` (`organization_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fiscal_periods`
--

LOCK TABLES `fiscal_periods` WRITE;
/*!40000 ALTER TABLE `fiscal_periods` DISABLE KEYS */;
/*!40000 ALTER TABLE `fiscal_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_transactions`
--

DROP TABLE IF EXISTS `inventory_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_transactions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `stock_location` enum('shop','store') NOT NULL DEFAULT 'shop',
  `transaction_type` enum('PURCHASE','POS_SALE','MOBILE_SALE','BACKEND_SALE','RETURN','DAMAGE','ADJUSTMENT','STOCK_TAKE','TRANSFER','WRITE_OFF','SUPPLIER_RETURN') NOT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` bigint DEFAULT NULL,
  `quantity_change` float NOT NULL,
  `quantity_before` float NOT NULL,
  `quantity_after` float NOT NULL,
  `unit_cost` decimal(10,2) DEFAULT NULL,
  `notes` text,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_code` (`product_code`),
  KEY `created_by` (`created_by`),
  KEY `idx_branch_product` (`branch_id`,`product_code`),
  KEY `idx_transaction_type` (`transaction_type`),
  KEY `idx_reference` (`reference_type`,`reference_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `inventory_transactions_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `inventory_transactions_ibfk_2` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`),
  CONSTRAINT `inventory_transactions_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_transactions`
--

LOCK TABLES `inventory_transactions` WRITE;
/*!40000 ALTER TABLE `inventory_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_transactions` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`steve`@`localhost`*/ /*!50003 TRIGGER `trg_sync_stock` AFTER INSERT ON `inventory_transactions` FOR EACH ROW BEGIN
    INSERT INTO current_stock (product_code, branch_id, shop_quantity, store_quantity)
    VALUES (
        NEW.product_code,
        NEW.branch_id,
        IF(NEW.stock_location = 'shop', NEW.quantity_after, 0),
        IF(NEW.stock_location = 'store', NEW.quantity_after, 0)
    )
    ON DUPLICATE KEY UPDATE
        shop_quantity  = IF(NEW.stock_location = 'shop', NEW.quantity_after, shop_quantity),
        store_quantity = IF(NEW.stock_location = 'store', NEW.quantity_after, store_quantity),
        last_updated   = CURRENT_TIMESTAMP;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_entries`
--

DROP TABLE IF EXISTS `journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal_entries` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `entry_number` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` bigint DEFAULT NULL,
  `description` text,
  `status` enum('draft','posted','void') NOT NULL DEFAULT 'draft',
  `created_by` int NOT NULL,
  `posted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_entry_number` (`organization_id`,`entry_number`),
  KEY `branch_id` (`branch_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `journal_entries_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `journal_entries_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `journal_entries_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_entries`
--

LOCK TABLES `journal_entries` WRITE;
/*!40000 ALTER TABLE `journal_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_entry_lines`
--

DROP TABLE IF EXISTS `journal_entry_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal_entry_lines` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `journal_entry_id` bigint NOT NULL,
  `account_id` int NOT NULL,
  `debit` decimal(14,2) NOT NULL DEFAULT '0.00',
  `credit` decimal(14,2) NOT NULL DEFAULT '0.00',
  `line_notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `journal_entry_id` (`journal_entry_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `journal_entry_lines_ibfk_1` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `journal_entry_lines_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_entry_lines`
--

LOCK TABLES `journal_entry_lines` WRITE;
/*!40000 ALTER TABLE `journal_entry_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal_entry_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kra_responses`
--

DROP TABLE IF EXISTS `kra_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kra_responses` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sale_id` bigint NOT NULL,
  `order_no` int NOT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `receipt_signature` text,
  `signature_link` text,
  `serial_number` varchar(255) DEFAULT NULL,
  `kra_timestamp` varchar(255) DEFAULT NULL,
  `request_payload` json DEFAULT NULL,
  `response_payload` json DEFAULT NULL,
  `status` enum('pending','success','failed') DEFAULT 'pending',
  `error_message` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `sale_id` (`sale_id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_status` (`status`),
  CONSTRAINT `kra_responses_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kra_responses`
--

LOCK TABLES `kra_responses` WRITE;
/*!40000 ALTER TABLE `kra_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `kra_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loading_list_lines`
--

DROP TABLE IF EXISTS `loading_list_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loading_list_lines` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `loading_list_id` bigint NOT NULL,
  `line_no` smallint unsigned NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` float NOT NULL,
  `quantity_label` varchar(120) DEFAULT NULL,
  `pack_breakdown` varchar(200) DEFAULT NULL,
  `unit_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(14,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `idx_loading_list_line` (`loading_list_id`,`line_no`),
  CONSTRAINT `loading_list_lines_ibfk_1` FOREIGN KEY (`loading_list_id`) REFERENCES `loading_lists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loading_list_lines`
--

LOCK TABLES `loading_list_lines` WRITE;
/*!40000 ALTER TABLE `loading_list_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `loading_list_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loading_lists`
--

DROP TABLE IF EXISTS `loading_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loading_lists` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `trip_id` bigint NOT NULL,
  `route_id` int DEFAULT NULL,
  `list_date` date NOT NULL,
  `status` enum('open','locked','loaded') NOT NULL DEFAULT 'open',
  `prepared_by_name` varchar(200) DEFAULT NULL,
  `checked_by_name` varchar(200) DEFAULT NULL,
  `locked_at` timestamp NULL DEFAULT NULL,
  `total_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_trip_loading_list` (`trip_id`),
  KEY `branch_id` (`branch_id`),
  KEY `route_id` (`route_id`),
  CONSTRAINT `loading_lists_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `loading_lists_ibfk_2` FOREIGN KEY (`trip_id`) REFERENCES `dispatch_trips` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loading_lists_ibfk_3` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loading_lists`
--

LOCK TABLES `loading_lists` WRITE;
/*!40000 ALTER TABLE `loading_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `loading_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_cards`
--

DROP TABLE IF EXISTS `loyalty_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `loyalty_cards` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `customer_num` int NOT NULL,
  `card_number` varchar(32) NOT NULL,
  `phone_number` varchar(45) NOT NULL,
  `points_balance` double NOT NULL DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `issued_at` date DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_loyalty_card` (`organization_id`,`card_number`),
  KEY `customer_num` (`customer_num`),
  KEY `created_by` (`created_by`),
  KEY `idx_loyalty_phone` (`organization_id`,`phone_number`),
  KEY `idx_loyalty_customer` (`organization_id`,`customer_num`),
  CONSTRAINT `loyalty_cards_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `loyalty_cards_ibfk_2` FOREIGN KEY (`customer_num`) REFERENCES `customers` (`customer_num`),
  CONSTRAINT `loyalty_cards_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_cards`
--

LOCK TABLES `loyalty_cards` WRITE;
/*!40000 ALTER TABLE `loyalty_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lpo_attachments`
--

DROP TABLE IF EXISTS `lpo_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lpo_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lpo_no` int NOT NULL,
  `file_name` varchar(200) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `file_size` int unsigned DEFAULT NULL,
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lpo_no` (`lpo_no`),
  CONSTRAINT `lpo_attachments_ibfk_1` FOREIGN KEY (`lpo_no`) REFERENCES `lpo_mst` (`lpo_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lpo_attachments`
--

LOCK TABLES `lpo_attachments` WRITE;
/*!40000 ALTER TABLE `lpo_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `lpo_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lpo_mst`
--

DROP TABLE IF EXISTS `lpo_mst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lpo_mst` (
  `lpo_no` int NOT NULL AUTO_INCREMENT,
  `supplier_id` int NOT NULL,
  `reference_number` varchar(45) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `vat_amount` float DEFAULT NULL,
  `net_amount` float DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_by` varchar(45) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `lpo_status_code` int DEFAULT '1',
  `delivery_address` varchar(45) DEFAULT NULL,
  `cleared_flag` int DEFAULT '0',
  `cleared_by` varchar(45) DEFAULT NULL,
  `cleared_at` datetime DEFAULT NULL,
  `email_sent_flag` int DEFAULT '0',
  `sent_at` datetime DEFAULT NULL,
  `sent_by` varchar(45) DEFAULT NULL,
  `supplier_invoice_no` varchar(45) DEFAULT NULL,
  `terms` varchar(200) DEFAULT NULL,
  `instructions` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`lpo_no`),
  KEY `created_by` (`created_by`),
  KEY `idx_supplier_id` (`supplier_id`),
  KEY `idx_lpo_status` (`lpo_status_code`),
  CONSTRAINT `lpo_mst_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `lpo_mst_ibfk_2` FOREIGN KEY (`lpo_status_code`) REFERENCES `lpo_statuses` (`status_code`),
  CONSTRAINT `lpo_mst_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lpo_mst`
--

LOCK TABLES `lpo_mst` WRITE;
/*!40000 ALTER TABLE `lpo_mst` DISABLE KEYS */;
/*!40000 ALTER TABLE `lpo_mst` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lpo_statuses`
--

DROP TABLE IF EXISTS `lpo_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lpo_statuses` (
  `status_code` int NOT NULL,
  `status_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`status_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lpo_statuses`
--

LOCK TABLES `lpo_statuses` WRITE;
/*!40000 ALTER TABLE `lpo_statuses` DISABLE KEYS */;
INSERT INTO `lpo_statuses` VALUES (0,'Pending Approval'),(1,'Not Sent'),(2,'Pending Received'),(3,'Partially Received'),(4,'Fully Received'),(5,'Cleared');
/*!40000 ALTER TABLE `lpo_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lpo_supplier_invoices`
--

DROP TABLE IF EXISTS `lpo_supplier_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lpo_supplier_invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lpo_no` int NOT NULL,
  `supplier_id` int NOT NULL,
  `supplier_invoice_number` varchar(100) NOT NULL,
  `invoice_date` date DEFAULT NULL,
  `invoice_amount` decimal(12,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `idx_lpo_no` (`lpo_no`),
  CONSTRAINT `lpo_supplier_invoices_ibfk_1` FOREIGN KEY (`lpo_no`) REFERENCES `lpo_mst` (`lpo_no`),
  CONSTRAINT `lpo_supplier_invoices_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lpo_supplier_invoices`
--

LOCK TABLES `lpo_supplier_invoices` WRITE;
/*!40000 ALTER TABLE `lpo_supplier_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `lpo_supplier_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lpo_txn`
--

DROP TABLE IF EXISTS `lpo_txn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lpo_txn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lpo_no` int NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `ordered_qty` double NOT NULL,
  `uom` varchar(45) DEFAULT NULL,
  `cost_price` double NOT NULL,
  `received_qty` double DEFAULT NULL,
  `markup_amount` float DEFAULT NULL,
  `markup_percent` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lpo_no` (`lpo_no`),
  KEY `idx_product_code` (`product_code`),
  CONSTRAINT `lpo_txn_ibfk_1` FOREIGN KEY (`lpo_no`) REFERENCES `lpo_mst` (`lpo_no`),
  CONSTRAINT `lpo_txn_ibfk_2` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lpo_txn`
--

LOCK TABLES `lpo_txn` WRITE;
/*!40000 ALTER TABLE `lpo_txn` DISABLE KEYS */;
/*!40000 ALTER TABLE `lpo_txn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_cache_table',1),(2,'0001_01_01_000001_create_sessions_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'0001_01_01_000003_create_personal_access_tokens_table',1),(5,'0002_01_01_000000_create_pos_erp_schema',1),(6,'2026_06_03_000001_mpesa_stk_payments',1),(7,'2026_06_04_000001_add_customer_location_and_shop_image',1),(8,'2026_06_04_000001_mpesa_incoming_payments',1),(9,'2026_06_04_000002_employee_clock_sessions',1),(10,'2026_06_04_000003_hr_shifts_leave_cash_advance',1),(11,'2026_06_04_000004_leave_range_clock_devices',1),(12,'2026_06_05_000001_leave_balances_settings',1),(13,'2026_06_06_000001_add_unpaid_sale_status',1),(14,'2026_06_06_000001_employee_overtime_rate_mode',1),(15,'2026_06_06_000002_payroll_cycle_settlements',1),(16,'2026_06_07_000001_employee_monthly_allowance',1),(17,'2026_06_07_000002_employee_allowances',1),(18,'2026_06_07_000003_payroll_deduction_applies_to_all',1),(19,'2026_06_08_000001_fix_cash_advance_repayment',1),(20,'2026_06_08_000002_payroll_runs_created_at',1),(21,'2026_06_09_000001_cart_lines_discount_given',1),(22,'2026_06_09_000002_uoms_packaging_labels',1),(23,'2026_06_09_000003_retail_package_pricing_tiers',1),(24,'2026_06_10_000001_routes_foreign_keys_null_on_delete',1),(25,'2026_06_10_000002_cart_lines_update_code',1),(26,'2026_06_10_000003_order_discount',1),(27,'2026_06_10_000004_create_vouchers_table',1),(28,'2026_06_10_000005_create_employee_kpis_table',1),(29,'2026_06_11_000001_create_customer_returns_tables',1),(30,'2026_06_11_000001_stock_reservations_cart_line_id',1),(31,'2026_06_11_000001_voucher_payment_loyalty',1),(32,'2026_06_11_000002_add_legacy_return_id_to_customer_return_lines',1),(33,'2026_06_11_000003_add_uom_to_customer_return_lines',1),(34,'2026_06_11_000004_create_credit_notes_table',1),(35,'2026_06_12_000001_add_order_source_to_sales',1),(36,'2026_06_12_000001_create_accounting_report_views',1),(37,'2026_06_12_000002_use_backoffice_order_source',1),(38,'2026_06_13_000001_add_delivered_sale_status',1),(39,'2026_06_13_000002_till_display_fields',1),(40,'2026_06_13_000003_tills_cashier_id_nullable',1),(41,'2026_06_13_000004_till_session_cash_movements',1),(42,'2026_06_13_000005_till_phase4_handover_legacy_cleanup',1),(43,'2026_06_13_000006_discount_voucher_on_cart',1),(44,'2026_06_15_000001_add_saas_tenant_access',1),(45,'2026_06_15_000001_user_permission_overrides',1),(46,'2026_06_15_000002_add_tenant_context_to_tokens',1),(47,'2026_06_15_000003_fix_profit_loss_summary_view',1),(48,'2026_06_16_000001_add_email_to_customers',1),(49,'2026_06_16_000001_add_super_admin_to_users',1),(50,'2026_06_16_000001_create_user_password_resets_table',1),(51,'2026_06_16_000001_user_login_channels',1),(52,'2026_06_17_000001_create_custom_report_templates_table',1),(53,'2026_06_17_000001_fiscal_periods',1),(54,'2026_06_17_000002_accounting_external_integration',1),(55,'2026_06_18_000001_create_supplier_payments_table',1),(56,'2026_06_19_000001_create_mobile_rep_attendance_sessions_table',1),(57,'2026_06_19_000001_create_supplier_return_documents_table',1),(58,'2026_06_19_000001_hr_report_views',1),(59,'2026_06_20_000001_add_distribution_report_views',1),(60,'2026_06_20_000001_create_distribution_phase2_tables',1),(61,'2026_06_21_000001_distribution_ops_enhancements',1),(62,'2026_06_22_000001_hr_approval_columns',1),(63,'2026_06_22_000001_organization_kpis',1),(64,'2026_06_23_000001_ai_knowledge_entries',1),(65,'2026_06_23_000001_user_mobile_order_scope',1),(66,'2026_06_24_000001_lpo_attachment_files',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_rep_attendance_sessions`
--

DROP TABLE IF EXISTS `mobile_rep_attendance_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobile_rep_attendance_sessions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `sign_in_at` datetime NOT NULL,
  `sign_out_at` datetime DEFAULT NULL,
  `sign_in_latitude` decimal(10,7) NOT NULL,
  `sign_in_longitude` decimal(10,7) NOT NULL,
  `sign_out_latitude` decimal(10,7) DEFAULT NULL,
  `sign_out_longitude` decimal(10,7) DEFAULT NULL,
  `sign_in_address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sign_out_address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sign_in_photo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sign_out_photo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_identifier` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mobile_rep_attendance_sessions_organization_id_foreign` (`organization_id`),
  KEY `mobile_rep_attendance_sessions_branch_id_foreign` (`branch_id`),
  KEY `idx_mobile_rep_attendance_open` (`user_id`,`sign_out_at`),
  CONSTRAINT `mobile_rep_attendance_sessions_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mobile_rep_attendance_sessions_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `mobile_rep_attendance_sessions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_rep_attendance_sessions`
--

LOCK TABLES `mobile_rep_attendance_sessions` WRITE;
/*!40000 ALTER TABLE `mobile_rep_attendance_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_rep_attendance_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mpesa_incoming_payments`
--

DROP TABLE IF EXISTS `mpesa_incoming_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mpesa_incoming_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint unsigned DEFAULT NULL,
  `transaction_id` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int unsigned NOT NULL,
  `applied_amount` int unsigned DEFAULT NULL,
  `source` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'c2b',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'available',
  `applied_cart_id` bigint unsigned DEFAULT NULL,
  `stk_request_id` bigint unsigned DEFAULT NULL,
  `received_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `applied_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mpesa_incoming_payments_transaction_id_unique` (`transaction_id`),
  KEY `mpesa_incoming_payments_phone_number_status_received_at_index` (`phone_number`,`status`,`received_at`),
  KEY `mpesa_incoming_payments_applied_cart_id_status_index` (`applied_cart_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mpesa_incoming_payments`
--

LOCK TABLES `mpesa_incoming_payments` WRITE;
/*!40000 ALTER TABLE `mpesa_incoming_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `mpesa_incoming_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mpesa_payment_skips`
--

DROP TABLE IF EXISTS `mpesa_payment_skips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mpesa_payment_skips` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cart_id` bigint unsigned NOT NULL,
  `mpesa_incoming_payment_id` bigint unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cart_mpesa_skip` (`cart_id`,`mpesa_incoming_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mpesa_payment_skips`
--

LOCK TABLES `mpesa_payment_skips` WRITE;
/*!40000 ALTER TABLE `mpesa_payment_skips` DISABLE KEYS */;
/*!40000 ALTER TABLE `mpesa_payment_skips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mpesa_stk_requests`
--

DROP TABLE IF EXISTS `mpesa_stk_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mpesa_stk_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cart_id` bigint unsigned NOT NULL,
  `organization_id` bigint unsigned NOT NULL,
  `phone_number` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int unsigned NOT NULL,
  `merchant_request_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `checkout_request_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` int unsigned DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `result_code` smallint unsigned DEFAULT NULL,
  `result_desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mpesa_stk_requests_checkout_request_id_unique` (`checkout_request_id`),
  KEY `mpesa_stk_requests_cart_id_status_index` (`cart_id`,`status`),
  KEY `mpesa_stk_requests_organization_id_created_at_index` (`organization_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mpesa_stk_requests`
--

LOCK TABLES `mpesa_stk_requests` WRITE;
/*!40000 ALTER TABLE `mpesa_stk_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `mpesa_stk_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_holidays`
--

DROP TABLE IF EXISTS `organization_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_holidays` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `holiday_date` date NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_holiday_date` (`organization_id`,`holiday_date`),
  CONSTRAINT `organization_holidays_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_holidays`
--

LOCK TABLES `organization_holidays` WRITE;
/*!40000 ALTER TABLE `organization_holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_kpis`
--

DROP TABLE IF EXISTS `organization_kpis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_kpis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `kpi_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `target_value` decimal(12,2) DEFAULT NULL,
  `unit` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `organization_kpis_created_by_foreign` (`created_by`),
  KEY `organization_kpis_organization_id_is_active_index` (`organization_id`,`is_active`),
  CONSTRAINT `organization_kpis_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `organization_kpis_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_kpis`
--

LOCK TABLES `organization_kpis` WRITE;
/*!40000 ALTER TABLE `organization_kpis` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_kpis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_leave_settings`
--

DROP TABLE IF EXISTS `organization_leave_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_leave_settings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `annual_leave_days` decimal(5,2) NOT NULL DEFAULT '21.00',
  `monthly_accrual_days` decimal(5,2) NOT NULL DEFAULT '1.75',
  `months_for_full_annual` tinyint unsigned NOT NULL DEFAULT '12',
  `sick_leave_days` decimal(5,2) NOT NULL DEFAULT '14.00',
  `sick_leave_full_pay_days` decimal(5,2) NOT NULL DEFAULT '7.00',
  `sick_leave_half_pay_days` decimal(5,2) NOT NULL DEFAULT '7.00',
  `months_before_sick_eligibility` tinyint unsigned NOT NULL DEFAULT '2',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organization_leave_settings_organization_id_unique` (`organization_id`),
  CONSTRAINT `organization_leave_settings_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_leave_settings`
--

LOCK TABLES `organization_leave_settings` WRITE;
/*!40000 ALTER TABLE `organization_leave_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_leave_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_code` varchar(45) NOT NULL,
  `logo` varchar(200) DEFAULT NULL,
  `org_name` varchar(200) NOT NULL,
  `org_email` varchar(200) NOT NULL,
  `primary_tel` varchar(45) NOT NULL,
  `secondary_tel` varchar(45) DEFAULT NULL,
  `addn_tel1` varchar(45) DEFAULT NULL,
  `addn_tel2` varchar(45) DEFAULT NULL,
  `org_address` varchar(400) NOT NULL,
  `org_pin` varchar(45) DEFAULT NULL,
  `vat_regno` varchar(50) DEFAULT NULL,
  `deployment_profile` enum('small_shop','wholesale_retail','distribution') NOT NULL DEFAULT 'wholesale_retail',
  `enabled_modules` json DEFAULT NULL,
  `module_settings` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `company_code` (`company_code`),
  KEY `idx_deployment_profile` (`deployment_profile`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES (1,'DEMO',NULL,'Demo Wholesalers Ltd','admin@demo.co.ke','0700111222',NULL,NULL,NULL,'Industrial Area, Nairobi, KE','P051234567Z','0123456789','wholesale_retail',NULL,'{\"sales\": {\"auto_assign_truck\": true, \"auto_assign_driver\": true}, \"finance\": {\"mpesa\": {\"env\": \"sandbox\", \"passkey\": \"\", \"shortcode\": \"\", \"till_number\": \"\", \"consumer_key\": \"\", \"consumer_secret\": \"\", \"stk_callback_url\": \"https://example.com/api/v1/payments/stk/callback\", \"c2b_validation_url\": \"https://example.com/api/v1/payments/c2b/validation\", \"c2b_confirmation_url\": \"https://example.com/api/v1/payments/c2b/confirmation\"}}, \"inventory\": {\"reserve_stock_on_cart\": true, \"default_pos_sale_location\": \"shop\"}}','2026-06-20 14:25:19','2026-06-20 14:25:19'),(2,'PLATFORM',NULL,'Platform Administration','alpacke.tech@gmail.com','0700000000',NULL,NULL,NULL,'Platform',NULL,NULL,'small_shop','{\"admin\": false, \"sales\": false, \"payments\": false, \"inventory\": false, \"sales.pos\": false, \"accounting\": false, \"hr_payroll\": false, \"distribution\": false, \"sales.mobile\": false, \"sales.backend\": false, \"sales.reports\": false, \"sales.dashboard\": false, \"inventory.reports\": false, \"accounting.reports\": false, \"hr_payroll.reports\": false, \"customers_suppliers\": false, \"inventory.dashboard\": false, \"accounting.dashboard\": false, \"distribution.reports\": false, \"hr_payroll.dashboard\": false, \"distribution.dashboard\": false, \"backoffice_finance_reports\": false, \"customers_suppliers.reports\": false, \"customers_suppliers.dashboard\": false}','{\"platform\": true}','2026-06-20 14:25:21','2026-06-20 14:25:21');
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_periods`
--

DROP TABLE IF EXISTS `pay_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_periods` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `period_code` varchar(45) NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `status` enum('open','closed') DEFAULT 'open',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_period` (`organization_id`,`period_code`),
  CONSTRAINT `pay_periods_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_periods`
--

LOCK TABLES `pay_periods` WRITE;
/*!40000 ALTER TABLE `pay_periods` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_methods` (
  `id` int NOT NULL AUTO_INCREMENT,
  `method_name` varchar(200) NOT NULL,
  `method_code` varchar(20) NOT NULL,
  `requires_reference` tinyint(1) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `method_name` (`method_name`),
  UNIQUE KEY `method_code` (`method_code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` VALUES (1,'Cash','CASH',0,1),(2,'M-Pesa','MPESA',1,1),(3,'Equity Bank','EQUITY',1,1),(4,'KCB Bank','KCB',1,1),(5,'Credit','CREDIT',0,1),(6,'Airtel Money','AIRTEL',1,1),(7,'Cheque','CHEQUE',1,1),(8,'Voucher','VOUCHER',1,1),(9,'Loyalty points','POINTS',1,1);
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_deduction_types`
--

DROP TABLE IF EXISTS `payroll_deduction_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_deduction_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `deduction_code` varchar(45) NOT NULL,
  `name` varchar(200) NOT NULL,
  `calc_type` enum('fixed','percentage') NOT NULL DEFAULT 'fixed',
  `default_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `default_percentage` decimal(5,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `applies_to_all` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_deduction_code` (`organization_id`,`deduction_code`),
  CONSTRAINT `payroll_deduction_types_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_deduction_types`
--

LOCK TABLES `payroll_deduction_types` WRITE;
/*!40000 ALTER TABLE `payroll_deduction_types` DISABLE KEYS */;
INSERT INTO `payroll_deduction_types` VALUES (1,1,'SACCO','SACCO contribution','fixed',1500.00,NULL,1,0,'2026-06-20 17:25:20');
/*!40000 ALTER TABLE `payroll_deduction_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_lines`
--

DROP TABLE IF EXISTS `payroll_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_lines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payroll_run_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `gross_pay` decimal(12,2) NOT NULL DEFAULT '0.00',
  `nssf` decimal(12,2) NOT NULL DEFAULT '0.00',
  `shif` decimal(12,2) NOT NULL DEFAULT '0.00',
  `housing_levy` decimal(12,2) NOT NULL DEFAULT '0.00',
  `paye` decimal(12,2) NOT NULL DEFAULT '0.00',
  `other_deductions` decimal(12,2) NOT NULL DEFAULT '0.00',
  `deductions` decimal(12,2) NOT NULL DEFAULT '0.00',
  `net_pay` decimal(12,2) NOT NULL DEFAULT '0.00',
  `taxable_income` decimal(12,2) NOT NULL DEFAULT '0.00',
  `employer_nssf` decimal(12,2) NOT NULL DEFAULT '0.00',
  `employer_housing` decimal(12,2) NOT NULL DEFAULT '0.00',
  `statutory_meta` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payroll_run_id` (`payroll_run_id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `payroll_lines_ibfk_1` FOREIGN KEY (`payroll_run_id`) REFERENCES `payroll_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payroll_lines_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_lines`
--

LOCK TABLES `payroll_lines` WRITE;
/*!40000 ALTER TABLE `payroll_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_run_settlements`
--

DROP TABLE IF EXISTS `payroll_run_settlements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_run_settlements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payroll_run_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `item_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` int unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payroll_run_settlement_item` (`payroll_run_id`,`item_type`,`item_id`),
  KEY `payroll_run_settlements_organization_id_item_type_index` (`organization_id`,`item_type`),
  CONSTRAINT `payroll_run_settlements_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payroll_run_settlements_payroll_run_id_foreign` FOREIGN KEY (`payroll_run_id`) REFERENCES `payroll_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_run_settlements`
--

LOCK TABLES `payroll_run_settlements` WRITE;
/*!40000 ALTER TABLE `payroll_run_settlements` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_run_settlements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_runs`
--

DROP TABLE IF EXISTS `payroll_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payroll_runs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pay_period_id` int NOT NULL,
  `run_date` date NOT NULL,
  `status` enum('draft','processed','paid','void') DEFAULT 'draft',
  `processed_by` int DEFAULT NULL,
  `total_gross` decimal(14,2) DEFAULT '0.00',
  `total_net` decimal(14,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `pay_period_id` (`pay_period_id`),
  KEY `processed_by` (`processed_by`),
  CONSTRAINT `payroll_runs_ibfk_1` FOREIGN KEY (`pay_period_id`) REFERENCES `pay_periods` (`id`),
  CONSTRAINT `payroll_runs_ibfk_2` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_runs`
--

LOCK TABLES `payroll_runs` WRITE;
/*!40000 ALTER TABLE `payroll_runs` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_runs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(100) NOT NULL,
  `permission_code` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_name` (`permission_name`),
  UNIQUE KEY `permission_code` (`permission_code`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'Dashboard / Dashboard — View','dashboard.overview.view','dashboard'),(2,'Catalog / Products — View','catalogue.products.view','catalogue'),(3,'Catalog / Products — Create','catalogue.products.create','catalogue'),(4,'Catalog / Products — Edit','catalogue.products.edit','catalogue'),(5,'Catalog / Products — Delete','catalogue.products.delete','catalogue'),(6,'Catalog / Categories & subcategories — View','catalogue.categories.view','catalogue'),(7,'Catalog / Categories & subcategories — Create','catalogue.categories.create','catalogue'),(8,'Catalog / Categories & subcategories — Edit','catalogue.categories.edit','catalogue'),(9,'Catalog / Categories & subcategories — Delete','catalogue.categories.delete','catalogue'),(10,'Catalog / Units of measure — View','catalogue.uoms.view','catalogue'),(11,'Catalog / Units of measure — Create','catalogue.uoms.create','catalogue'),(12,'Catalog / Units of measure — Edit','catalogue.uoms.edit','catalogue'),(13,'Catalog / Units of measure — Delete','catalogue.uoms.delete','catalogue'),(14,'Catalog / Retail packages — View','catalogue.retail_packages.view','catalogue'),(15,'Catalog / Retail packages — Edit','catalogue.retail_packages.edit','catalogue'),(16,'Catalog / VAT rates — View','catalogue.vat_rates.view','catalogue'),(17,'Catalog / VAT rates — Create','catalogue.vat_rates.create','catalogue'),(18,'Catalog / VAT rates — Edit','catalogue.vat_rates.edit','catalogue'),(19,'Catalog / VAT rates — Delete','catalogue.vat_rates.delete','catalogue'),(20,'Catalog / Price history — View','catalogue.price_history.view','catalogue'),(21,'Customers / Customers — View','customers.customers.view','customers'),(22,'Customers / Customers — Create','customers.customers.create','customers'),(23,'Customers / Customers — Edit','customers.customers.edit','customers'),(24,'Customers / Customers — Delete','customers.customers.delete','customers'),(25,'Customers / Customer statements — View','customers.statements.view','customers'),(26,'Sales / Sales dashboard — View','sales.dashboard.view','sales'),(27,'Sales / Orders & queues — View','sales.orders.view','sales'),(28,'Sales / Orders & queues — Create','sales.orders.create','sales'),(29,'Sales / Orders & queues — Edit','sales.orders.edit','sales'),(30,'Sales / Orders & queues — Delete','sales.orders.delete','sales'),(31,'Sales / Orders & queues — Approve','sales.orders.approve','sales'),(32,'Sales / Carts (read-only) — View','sales.carts.view','sales'),(33,'Sales / Vouchers — View','sales.vouchers.view','sales'),(34,'Sales / Vouchers — Create','sales.vouchers.create','sales'),(35,'Sales / Vouchers — Edit','sales.vouchers.edit','sales'),(36,'Sales / Vouchers — Delete','sales.vouchers.delete','sales'),(37,'Sales / Loyalty cards — View','sales.loyalty_cards.view','sales'),(38,'Sales / Loyalty cards — Create','sales.loyalty_cards.create','sales'),(39,'Sales / Loyalty cards — Edit','sales.loyalty_cards.edit','sales'),(40,'Sales / Loyalty cards — Delete','sales.loyalty_cards.delete','sales'),(41,'Sales / Reservations — View','sales.reservations.view','sales'),(42,'Sales / Reservations — Create','sales.reservations.create','sales'),(43,'Sales / Reservations — Edit','sales.reservations.edit','sales'),(44,'Sales / Reservations — Delete','sales.reservations.delete','sales'),(45,'Sales / Customer returns — View','sales.returns.view','sales'),(46,'Sales / Customer returns — Create','sales.returns.create','sales'),(47,'Mobile application / Dashboard & KPIs — View','mobile.dashboard.view','mobile'),(48,'Mobile application / Orders & checkout — View','mobile.orders.view','mobile'),(49,'Mobile application / Orders & checkout — Create','mobile.orders.create','mobile'),(50,'Mobile application / Orders & checkout — Edit','mobile.orders.edit','mobile'),(51,'Mobile application / Customers — View','mobile.customers.view','mobile'),(52,'Mobile application / Customers — Create','mobile.customers.create','mobile'),(53,'Mobile application / Customers — Edit','mobile.customers.edit','mobile'),(54,'Mobile application / Product search — View','mobile.catalog.view','mobile'),(55,'Mobile application / Stock levels — View','mobile.stock.view','mobile'),(56,'Mobile application / Route selection — View','mobile.routes.view','mobile'),(57,'Sales / POS till management — View','pos.till_management.view','pos'),(58,'Sales / POS till management — Create','pos.till_management.create','pos'),(59,'Sales / POS till management — Edit','pos.till_management.edit','pos'),(60,'Sales / Create order (Backoffice POS) — Create','pos.checkout.create','pos'),(61,'Sales / External POS — View','pos.terminal.view','pos'),(62,'Sales / POS end of day — View','pos.end_of_day.view','pos'),(63,'Payments / Sale payments — View','payments.sale_payments.view','payments'),(64,'Payments / Sale payments — Create','payments.sale_payments.create','payments'),(65,'Payments / Sale payments — Edit','payments.sale_payments.edit','payments'),(66,'Payments / Customer invoices — View','payments.customer_invoices.view','payments'),(67,'Payments / Customer invoices — Create','payments.customer_invoices.create','payments'),(68,'Payments / Customer invoices — Edit','payments.customer_invoices.edit','payments'),(69,'Payments / Customer invoice payments — View','payments.customer_payments.view','payments'),(70,'Payments / Customer invoice payments — Create','payments.customer_payments.create','payments'),(71,'Payments / Customer invoice payments — Edit','payments.customer_payments.edit','payments'),(72,'Inventory / Current stock — View','inventory.stock.view','inventory'),(73,'Inventory / Stock receipts — View','inventory.receipts.view','inventory'),(74,'Inventory / Stock receipts — Create','inventory.receipts.create','inventory'),(75,'Inventory / Stock receipts — Approve','inventory.receipts.approve','inventory'),(76,'Inventory / Stock movements — View','inventory.movements.view','inventory'),(77,'Inventory / Stock transfers — View','inventory.transfers.view','inventory'),(78,'Inventory / Stock transfers — Create','inventory.transfers.create','inventory'),(79,'Inventory / Damages — View','inventory.damages.view','inventory'),(80,'Inventory / Damages — Create','inventory.damages.create','inventory'),(81,'Inventory / Stock take — View','inventory.stock_take.view','inventory'),(82,'Inventory / Stock take — Create','inventory.stock_take.create','inventory'),(83,'Inventory / Stock take — Approve','inventory.stock_take.approve','inventory'),(84,'Procurement / Purchase orders — View','purchasing.lpo.view','purchasing'),(85,'Procurement / Purchase orders — Create','purchasing.lpo.create','purchasing'),(86,'Procurement / Purchase orders — Edit','purchasing.lpo.edit','purchasing'),(87,'Procurement / Purchase orders — Delete','purchasing.lpo.delete','purchasing'),(88,'Procurement / Purchase orders — Approve','purchasing.lpo.approve','purchasing'),(89,'Procurement / Suppliers — View','purchasing.suppliers.view','purchasing'),(90,'Procurement / Suppliers — Create','purchasing.suppliers.create','purchasing'),(91,'Procurement / Suppliers — Edit','purchasing.suppliers.edit','purchasing'),(92,'Procurement / Suppliers — Delete','purchasing.suppliers.delete','purchasing'),(93,'Procurement / Supplier payments — View','purchasing.supplier_payments.view','purchasing'),(94,'Procurement / Supplier payments — Create','purchasing.supplier_payments.create','purchasing'),(95,'Procurement / Supplier returns — View','purchasing.supplier_returns.view','purchasing'),(96,'Procurement / Supplier returns — Create','purchasing.supplier_returns.create','purchasing'),(97,'Fulfillment / Drivers — View','fulfillment.drivers.view','fulfillment'),(98,'Fulfillment / Drivers — Create','fulfillment.drivers.create','fulfillment'),(99,'Fulfillment / Drivers — Edit','fulfillment.drivers.edit','fulfillment'),(100,'Fulfillment / Drivers — Delete','fulfillment.drivers.delete','fulfillment'),(101,'Fulfillment / Vehicles — View','fulfillment.vehicles.view','fulfillment'),(102,'Fulfillment / Vehicles — Create','fulfillment.vehicles.create','fulfillment'),(103,'Fulfillment / Vehicles — Edit','fulfillment.vehicles.edit','fulfillment'),(104,'Fulfillment / Vehicles — Delete','fulfillment.vehicles.delete','fulfillment'),(105,'Fulfillment / Routes — View','fulfillment.routes.view','fulfillment'),(106,'Fulfillment / Routes — Create','fulfillment.routes.create','fulfillment'),(107,'Fulfillment / Routes — Edit','fulfillment.routes.edit','fulfillment'),(108,'Fulfillment / Routes — Delete','fulfillment.routes.delete','fulfillment'),(109,'Accounting / Accounting dashboard — View','accounting.dashboard.view','accounting'),(110,'Accounting / Chart of accounts — View','accounting.chart_of_accounts.view','accounting'),(111,'Accounting / Chart of accounts — Create','accounting.chart_of_accounts.create','accounting'),(112,'Accounting / Chart of accounts — Edit','accounting.chart_of_accounts.edit','accounting'),(113,'Accounting / Chart of accounts — Delete','accounting.chart_of_accounts.delete','accounting'),(114,'Accounting / Journal entries — View','accounting.journal_entries.view','accounting'),(115,'Accounting / Journal entries — Create','accounting.journal_entries.create','accounting'),(116,'Accounting / Journal entries — Edit','accounting.journal_entries.edit','accounting'),(117,'Accounting / Journal entries — Delete','accounting.journal_entries.delete','accounting'),(118,'Accounting / Journal entries — Approve','accounting.journal_entries.approve','accounting'),(119,'Accounting / Fiscal periods — View','accounting.fiscal_periods.view','accounting'),(120,'Accounting / Fiscal periods — Edit','accounting.fiscal_periods.edit','accounting'),(121,'Accounting / Fiscal periods — Approve','accounting.fiscal_periods.approve','accounting'),(122,'Accounting / Accounting settings — View','accounting.settings.view','accounting'),(123,'Accounting / Accounting settings — Edit','accounting.settings.edit','accounting'),(124,'Accounting / Account mappings — View','accounting.account_mappings.view','accounting'),(125,'Accounting / Account mappings — Edit','accounting.account_mappings.edit','accounting'),(126,'Accounting / Export queue — View','accounting.export_queue.view','accounting'),(127,'Accounting / General ledger — View','accounting.general_ledger.view','accounting'),(128,'Accounting / Trial balance — View','accounting.trial_balance.view','accounting'),(129,'Accounting / Profit & loss — View','accounting.profit_loss.view','accounting'),(130,'Accounting / Balance sheet — View','accounting.balance_sheet.view','accounting'),(131,'Accounting / Cash flow — View','accounting.cash_flow.view','accounting'),(132,'Accounting / Accounts receivable — View','accounting.accounts_receivable.view','accounting'),(133,'Accounting / Accounts payable — View','accounting.accounts_payable.view','accounting'),(134,'Accounting / Expenses — View','accounting.expenses.view','accounting'),(135,'Accounting / Expenses — Create','accounting.expenses.create','accounting'),(136,'Accounting / Expenses — Edit','accounting.expenses.edit','accounting'),(137,'Accounting / Expenses — Delete','accounting.expenses.delete','accounting'),(138,'Reports / All reports — View','reports.hub.view','reports'),(139,'Reports / Daily sales — View','reports.daily_sales.view','reports'),(140,'Reports / Stock on hand — View','reports.stock_on_hand.view','reports'),(141,'Reports / Profit & loss — View','reports.profit_loss.view','reports'),(142,'Reports / Top debtors — View','reports.top_debtors.view','reports'),(143,'Reports / Stock movement — View','reports.stock_movement.view','reports'),(144,'Reports / VAT collected — View','reports.vat_collected.view','reports'),(145,'Reports / Till sessions — View','reports.till_sessions.view','reports'),(146,'Reports / Expenses report — View','reports.expenses.view','reports'),(147,'Reports / Customer statement — View','reports.customer_statement.view','reports'),(148,'Reports / Report builder — View','reports.builder.view','reports'),(149,'Reports / Report builder — Create','reports.builder.create','reports'),(150,'Reports / Report builder — Edit','reports.builder.edit','reports'),(151,'Reports / Report builder — Delete','reports.builder.delete','reports'),(152,'AI assistant / AI assistant — Create','ai.assist.create','ai'),(153,'HR & Payroll / Employees — View','hr.employees.view','hr'),(154,'HR & Payroll / Employees — Create','hr.employees.create','hr'),(155,'HR & Payroll / Employees — Edit','hr.employees.edit','hr'),(156,'HR & Payroll / Employees — Delete','hr.employees.delete','hr'),(157,'HR & Payroll / Departments — View','hr.departments.view','hr'),(158,'HR & Payroll / Departments — Create','hr.departments.create','hr'),(159,'HR & Payroll / Departments — Edit','hr.departments.edit','hr'),(160,'HR & Payroll / Departments — Delete','hr.departments.delete','hr'),(161,'HR & Payroll / Positions — View','hr.positions.view','hr'),(162,'HR & Payroll / Positions — Create','hr.positions.create','hr'),(163,'HR & Payroll / Positions — Edit','hr.positions.edit','hr'),(164,'HR & Payroll / Positions — Delete','hr.positions.delete','hr'),(165,'HR & Payroll / Employee KPIs — View','hr.kpis.view','hr'),(166,'HR & Payroll / Employee KPIs — Create','hr.kpis.create','hr'),(167,'HR & Payroll / Employee KPIs — Edit','hr.kpis.edit','hr'),(168,'HR & Payroll / Employee KPIs — Delete','hr.kpis.delete','hr'),(169,'HR & Payroll / Shifts — View','hr.shifts.view','hr'),(170,'HR & Payroll / Shifts — Create','hr.shifts.create','hr'),(171,'HR & Payroll / Shifts — Edit','hr.shifts.edit','hr'),(172,'HR & Payroll / Shifts — Delete','hr.shifts.delete','hr'),(173,'HR & Payroll / Allowances — View','hr.allowances.view','hr'),(174,'HR & Payroll / Allowances — Create','hr.allowances.create','hr'),(175,'HR & Payroll / Allowances — Edit','hr.allowances.edit','hr'),(176,'HR & Payroll / Allowances — Delete','hr.allowances.delete','hr'),(177,'HR & Payroll / Deductions — View','hr.deductions.view','hr'),(178,'HR & Payroll / Deductions — Create','hr.deductions.create','hr'),(179,'HR & Payroll / Deductions — Edit','hr.deductions.edit','hr'),(180,'HR & Payroll / Deductions — Delete','hr.deductions.delete','hr'),(181,'HR & Payroll / Overtime — View','hr.overtime.view','hr'),(182,'HR & Payroll / Overtime — Create','hr.overtime.create','hr'),(183,'HR & Payroll / Overtime — Edit','hr.overtime.edit','hr'),(184,'HR & Payroll / Overtime — Delete','hr.overtime.delete','hr'),(185,'HR & Payroll / Cash advances — View','hr.cash_advances.view','hr'),(186,'HR & Payroll / Cash advances — Create','hr.cash_advances.create','hr'),(187,'HR & Payroll / Cash advances — Edit','hr.cash_advances.edit','hr'),(188,'HR & Payroll / Cash advances — Approve','hr.cash_advances.approve','hr'),(189,'HR & Payroll / Attendance — View','hr.attendance.view','hr'),(190,'HR & Payroll / Attendance — Create','hr.attendance.create','hr'),(191,'HR & Payroll / Leave & off days — View','hr.leave.view','hr'),(192,'HR & Payroll / Leave & off days — Create','hr.leave.create','hr'),(193,'HR & Payroll / Leave & off days — Edit','hr.leave.edit','hr'),(194,'HR & Payroll / Leave & off days — Approve','hr.leave.approve','hr'),(195,'HR & Payroll / Payroll — View','hr.payroll.view','hr'),(196,'HR & Payroll / Payroll — Create','hr.payroll.create','hr'),(197,'HR & Payroll / Payroll — Approve','hr.payroll.approve','hr'),(198,'HR & Payroll / Public holidays — View','hr.holidays.view','hr'),(199,'HR & Payroll / Public holidays — Create','hr.holidays.create','hr'),(200,'HR & Payroll / Public holidays — Edit','hr.holidays.edit','hr'),(201,'HR & Payroll / Public holidays — Delete','hr.holidays.delete','hr'),(202,'HR & Payroll / Leave settings — View','hr.leave_settings.view','hr'),(203,'HR & Payroll / Leave settings — Edit','hr.leave_settings.edit','hr'),(204,'Administration / Admin overview — View','admin.overview.view','admin'),(205,'Administration / Company profile — View','admin.company.view','admin'),(206,'Administration / Company profile — Edit','admin.company.edit','admin'),(207,'Administration / Branches — View','admin.branches.view','admin'),(208,'Administration / Branches — Create','admin.branches.create','admin'),(209,'Administration / Branches — Edit','admin.branches.edit','admin'),(210,'Administration / Branches — Delete','admin.branches.delete','admin'),(211,'Administration / Users — View','admin.users.view','admin'),(212,'Administration / Users — Create','admin.users.create','admin'),(213,'Administration / Users — Edit','admin.users.edit','admin'),(214,'Administration / Users — Delete','admin.users.delete','admin'),(215,'Administration / Roles & permissions — View','admin.roles.view','admin'),(216,'Administration / Roles & permissions — Edit','admin.roles.edit','admin'),(217,'Administration / Audit trail — View','admin.audit.view','admin'),(218,'Administration / System settings — View','admin.settings.view','admin'),(219,'Administration / System settings — Edit','admin.settings.edit','admin'),(220,'Administration / Payment methods — View','admin.payment_methods.view','admin'),(221,'Administration / Payment methods — Create','admin.payment_methods.create','admin'),(222,'Administration / Payment methods — Edit','admin.payment_methods.edit','admin'),(223,'Administration / Payment methods — Delete','admin.payment_methods.delete','admin'),(224,'Process sales, carts, checkout','sales.create','sales'),(225,'Update order workflow / transitions','sales.manage','sales'),(226,'View sales orders and related records','sales.view','sales'),(227,'Use the LightStores mobile field sales app','mobile.access','mobile'),(228,'Record payments on sales and AR','payments.manage','payments'),(229,'View payment and invoice records','payments.view','payments'),(230,'Stock adjust, transfer, receive, returns','inventory.manage','inventory'),(231,'View stock availability','inventory.view','inventory'),(232,'View product catalogue','catalogue.view','catalogue'),(233,'Run reports','reports.view','reports'),(234,'Build custom reports','reports.builder','reports'),(235,'Use AI assistant','ai.assist','ai'),(236,'View LPOs, suppliers, and supplier payments','purchasing.view','purchasing'),(237,'LPO and supplier operations','purchasing.manage','purchasing'),(238,'View customers and statements','customers.view','customers'),(239,'Manage customers','customers.manage','customers'),(240,'View drivers, vehicles, and routes','fulfillment.view','fulfillment'),(241,'Manage drivers, vehicles, and routes','fulfillment.manage','fulfillment'),(242,'View chart of accounts and journals','accounting.view','accounting'),(243,'Create, post, and reverse journal entries','accounting.manage','accounting'),(244,'View HR records','hr.view','hr'),(245,'Payroll processing','hr.manage','hr'),(246,'View administration settings','admin.view','admin'),(247,'Users, roles, org settings','admin.manage','admin'),(248,'Open/close till sessions and X/Z reports','pos.till','pos'),(249,'Product catalogue and KRA device register','products.manage','catalogue');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `organization_id` int DEFAULT NULL,
  `user_membership_id` bigint unsigned DEFAULT NULL,
  `login_channel` varchar(20) NOT NULL DEFAULT 'backoffice',
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pod_lines`
--

DROP TABLE IF EXISTS `pod_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pod_lines` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `pod_record_id` bigint NOT NULL,
  `sale_item_id` bigint NOT NULL,
  `qty_ordered` float NOT NULL,
  `qty_delivered` float NOT NULL,
  `qty_refused` float NOT NULL DEFAULT '0',
  `reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pod_record_id` (`pod_record_id`),
  KEY `sale_item_id` (`sale_item_id`),
  CONSTRAINT `pod_lines_ibfk_1` FOREIGN KEY (`pod_record_id`) REFERENCES `pod_records` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pod_lines_ibfk_2` FOREIGN KEY (`sale_item_id`) REFERENCES `sale_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pod_lines`
--

LOCK TABLES `pod_lines` WRITE;
/*!40000 ALTER TABLE `pod_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `pod_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pod_records`
--

DROP TABLE IF EXISTS `pod_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pod_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `sale_id` bigint NOT NULL,
  `trip_id` bigint DEFAULT NULL,
  `captured_at` timestamp NOT NULL,
  `captured_by` int DEFAULT NULL,
  `recipient_name` varchar(200) NOT NULL,
  `notes` text,
  `signature_path` varchar(500) DEFAULT NULL,
  `photo_path` varchar(500) DEFAULT NULL,
  `status` enum('complete','partial','refused') NOT NULL DEFAULT 'complete',
  `gps_lat` decimal(10,7) DEFAULT NULL,
  `gps_lng` decimal(10,7) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `captured_by` (`captured_by`),
  KEY `idx_pod_sale` (`sale_id`),
  KEY `idx_pod_trip` (`trip_id`),
  CONSTRAINT `pod_records_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `pod_records_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pod_records_ibfk_3` FOREIGN KEY (`trip_id`) REFERENCES `dispatch_trips` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pod_records_ibfk_4` FOREIGN KEY (`captured_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pod_records`
--

LOCK TABLES `pod_records` WRITE;
/*!40000 ALTER TABLE `pod_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `pod_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `positions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `position_code` varchar(45) NOT NULL,
  `position_title` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_position` (`organization_id`,`position_code`),
  CONSTRAINT `positions_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `positions`
--

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,1,'GM','General Manager',NULL,1,'2026-06-20 17:25:20');
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_history`
--

DROP TABLE IF EXISTS `price_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_code` varchar(200) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `cost_price` decimal(10,2) NOT NULL,
  `discount_pct` decimal(10,2) DEFAULT '0.00',
  `changed_by` int NOT NULL,
  `organization_id` int NOT NULL,
  `changed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `changed_by` (`changed_by`),
  KEY `organization_id` (`organization_id`),
  KEY `idx_product_code` (`product_code`),
  KEY `idx_changed_at` (`changed_at`),
  CONSTRAINT `price_history_ibfk_1` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`),
  CONSTRAINT `price_history_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`),
  CONSTRAINT `price_history_ibfk_3` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_history`
--

LOCK TABLES `price_history` WRITE;
/*!40000 ALTER TABLE `price_history` DISABLE KEYS */;
INSERT INTO `price_history` VALUES (1,'6161100100015',5500.00,4800.00,0.00,1,1,'2026-05-21 14:25:21'),(2,'6161100100015',5750.00,4900.00,0.00,1,1,'2026-06-06 14:25:21'),(3,'6161100100015',6000.00,5100.00,0.00,1,1,'2026-06-18 14:25:21');
/*!40000 ALTER TABLE `price_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_code` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `subcategory_id` int NOT NULL,
  `unit_id` int NOT NULL,
  `unit_price` float NOT NULL,
  `last_selling_price` float DEFAULT '0',
  `last_cost_price` float DEFAULT NULL,
  `discount_type` enum('fixed','percentage') DEFAULT 'percentage',
  `discount_percentage` float NOT NULL DEFAULT '0',
  `discount_value` float DEFAULT '0',
  `product_weight` double DEFAULT NULL,
  `stock_in_shop` float NOT NULL DEFAULT '0',
  `stock_in_store` float DEFAULT '0',
  `supplier_id` int DEFAULT NULL,
  `sell_on_retail` tinyint DEFAULT '0',
  `vat_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `reorder_point` decimal(10,2) DEFAULT '0.00',
  `low_stock_alert_enabled` tinyint(1) DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`),
  KEY `unit_id` (`unit_id`),
  KEY `vat_id` (`vat_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `organization_id` (`organization_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_product_code` (`product_code`),
  KEY `idx_subcategory_id` (`subcategory_id`),
  KEY `idx_deleted_at` (`deleted_at`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`subcategory_id`) REFERENCES `sub_categories` (`id`),
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`unit_id`) REFERENCES `uoms` (`id`),
  CONSTRAINT `products_ibfk_3` FOREIGN KEY (`vat_id`) REFERENCES `vats` (`id`),
  CONSTRAINT `products_ibfk_4` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `products_ibfk_5` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `products_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `products_ibfk_7` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'6161100100015','Mumias White Sugar 50kg',1,1,6000,0,NULL,'percentage',0,0,NULL,2500,5000,1,1,1,1,500.00,1,1,1,'2026-06-20 14:25:21','2026-06-20 14:25:21',NULL,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retail_package_settings`
--

DROP TABLE IF EXISTS `retail_package_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `retail_package_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_code` varchar(200) NOT NULL,
  `max_qty_measure` float DEFAULT NULL,
  `markup_price` float DEFAULT '0',
  `min_uom_measure` varchar(45) DEFAULT NULL,
  `wholesale_qty_measure` float DEFAULT '0',
  `wholesale_markup_price` float DEFAULT '0',
  `max_uom_measure` varchar(45) DEFAULT NULL,
  `pricing_tiers` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_product_code` (`product_code`),
  CONSTRAINT `retail_package_settings_ibfk_1` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retail_package_settings`
--

LOCK TABLES `retail_package_settings` WRITE;
/*!40000 ALTER TABLE `retail_package_settings` DISABLE KEYS */;
INSERT INTO `retail_package_settings` VALUES (1,'6161100100015',50,5,'kg',0,10,'bag',NULL,'2026-06-20 17:25:21');
/*!40000 ALTER TABLE `retail_package_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `returns`
--

DROP TABLE IF EXISTS `returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `returns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_id` bigint DEFAULT NULL,
  `branch_id` int NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `quantity` float NOT NULL,
  `uom` varchar(45) DEFAULT NULL,
  `amount` float NOT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `return_type` enum('CURRENT','PREVIOUS','MOBILE','SUPPLIER') NOT NULL DEFAULT 'CURRENT',
  `item_code` varchar(50) DEFAULT NULL,
  `returned_by` int NOT NULL,
  `is_mobile` tinyint DEFAULT '0',
  `created_at` date DEFAULT (curdate()),
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `returned_by` (`returned_by`),
  KEY `idx_sale_id` (`sale_id`),
  KEY `idx_product_code` (`product_code`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `returns_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
  CONSTRAINT `returns_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `returns_ibfk_3` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`),
  CONSTRAINT `returns_ibfk_4` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returns`
--

LOCK TABLES `returns` WRITE;
/*!40000 ALTER TABLE `returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(1,2),(7,2),(8,2),(1,3),(1,4),(1,5),(1,6),(7,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20),(1,21),(3,21),(7,21),(1,22),(1,23),(3,23),(1,24),(1,25),(1,26),(2,26),(3,26),(7,26),(1,27),(2,27),(3,27),(7,27),(1,28),(2,28),(3,28),(8,28),(1,29),(3,29),(1,30),(1,31),(1,32),(1,33),(3,33),(1,34),(1,35),(1,36),(1,37),(1,38),(1,39),(1,40),(1,41),(3,41),(1,42),(1,43),(1,44),(1,45),(3,45),(1,46),(3,46),(1,47),(8,47),(1,48),(8,48),(1,49),(8,49),(1,50),(8,50),(1,51),(8,51),(1,52),(8,52),(1,53),(8,53),(1,54),(8,54),(1,55),(8,55),(1,56),(8,56),(1,57),(2,57),(1,58),(2,58),(1,59),(1,60),(1,61),(2,61),(1,62),(2,62),(3,62),(1,63),(2,63),(3,63),(1,64),(2,64),(3,64),(8,64),(1,65),(1,66),(1,67),(1,68),(1,69),(1,70),(1,71),(1,72),(2,72),(3,72),(4,72),(7,72),(8,72),(1,73),(3,73),(4,73),(1,74),(4,74),(1,75),(1,76),(3,76),(4,76),(1,77),(3,77),(4,77),(1,78),(3,78),(4,78),(1,79),(3,79),(4,79),(1,80),(3,80),(4,80),(1,81),(3,81),(4,81),(1,82),(4,82),(1,83),(1,84),(3,84),(4,84),(7,84),(1,85),(3,85),(1,86),(3,86),(1,87),(1,88),(1,89),(3,89),(4,89),(7,89),(1,90),(1,91),(1,92),(1,93),(3,93),(5,93),(1,94),(3,94),(1,95),(3,95),(4,95),(1,96),(3,96),(4,96),(1,97),(1,98),(1,99),(1,100),(1,101),(1,102),(1,103),(1,104),(1,105),(1,106),(1,107),(1,108),(1,109),(5,109),(1,110),(5,110),(1,111),(1,112),(1,113),(1,114),(5,114),(1,115),(5,115),(1,116),(1,117),(1,118),(1,119),(5,119),(1,120),(1,121),(1,122),(1,123),(1,124),(5,124),(1,125),(1,126),(5,126),(1,127),(5,127),(1,128),(5,128),(1,129),(5,129),(1,130),(5,130),(1,131),(5,131),(1,132),(5,132),(1,133),(5,133),(1,134),(5,134),(1,135),(1,136),(1,137),(1,138),(3,138),(5,138),(6,138),(7,138),(1,139),(3,139),(7,139),(1,140),(3,140),(7,140),(1,141),(3,141),(5,141),(1,142),(1,143),(1,144),(1,145),(1,146),(5,146),(1,147),(1,148),(1,149),(1,150),(1,151),(1,152),(1,153),(6,153),(1,154),(1,155),(1,156),(1,157),(6,157),(1,158),(1,159),(1,160),(1,161),(1,162),(1,163),(1,164),(1,165),(6,165),(1,166),(1,167),(1,168),(1,169),(1,170),(1,171),(1,172),(1,173),(1,174),(1,175),(1,176),(1,177),(1,178),(1,179),(1,180),(1,181),(1,182),(1,183),(1,184),(1,185),(1,186),(1,187),(1,188),(1,189),(6,189),(1,190),(1,191),(6,191),(1,192),(1,193),(1,194),(1,195),(6,195),(1,196),(6,196),(1,197),(1,198),(1,199),(1,200),(1,201),(1,202),(1,203),(1,204),(1,205),(1,206),(1,207),(3,207),(1,208),(1,209),(1,210),(1,211),(3,211),(1,212),(1,213),(1,214),(1,215),(1,216),(1,217),(1,218),(1,219),(1,220),(5,220),(1,221),(1,222),(1,223),(1,224),(1,225),(1,226),(1,227),(1,228),(1,229),(1,230),(1,231),(1,232),(1,233),(1,234),(1,235),(1,236),(1,237),(1,238),(1,239),(1,240),(1,241),(1,242),(1,243),(1,244),(1,245),(1,246),(1,247),(1,248),(1,249);
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `role_name` varchar(250) NOT NULL,
  `scope` enum('org','branch') NOT NULL DEFAULT 'branch',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_role_name` (`organization_id`,`role_name`),
  CONSTRAINT `roles_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,NULL,'Administrator','org',1,'2026-06-20 17:25:19'),(2,NULL,'Cashier','branch',1,'2026-06-20 17:25:19'),(3,NULL,'Branch Manager','org',1,'2026-06-20 17:25:20'),(4,NULL,'Stock Clerk','branch',1,'2026-06-20 17:25:20'),(5,NULL,'Accountant','branch',1,'2026-06-20 17:25:20'),(6,NULL,'Payroll Clerk','branch',1,'2026-06-20 17:25:20'),(7,NULL,'Viewer','branch',1,'2026-06-20 17:25:20'),(8,NULL,'Mobile Sales Rep','branch',1,'2026-06-20 17:25:20'),(9,NULL,'Platform Operator','org',1,'2026-06-20 17:25:21');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route_schedules`
--

DROP TABLE IF EXISTS `route_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route_schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `route_id` int NOT NULL,
  `day_of_week` tinyint unsigned NOT NULL,
  `default_driver_id` int DEFAULT NULL,
  `default_vehicle_id` int DEFAULT NULL,
  `departure_time` time DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_branch_route_day` (`branch_id`,`route_id`,`day_of_week`),
  KEY `route_id` (`route_id`),
  KEY `default_driver_id` (`default_driver_id`),
  KEY `default_vehicle_id` (`default_vehicle_id`),
  CONSTRAINT `route_schedules_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `route_schedules_ibfk_2` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `route_schedules_ibfk_3` FOREIGN KEY (`default_driver_id`) REFERENCES `drivers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `route_schedules_ibfk_4` FOREIGN KEY (`default_vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route_schedules`
--

LOCK TABLES `route_schedules` WRITE;
/*!40000 ALTER TABLE `route_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `route_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routes`
--

DROP TABLE IF EXISTS `routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `route_name` varchar(255) NOT NULL,
  `route_markup_price` int DEFAULT '0',
  `direction` varchar(45) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `route_name` (`route_name`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routes`
--

LOCK TABLES `routes` WRITE;
/*!40000 ALTER TABLE `routes` DISABLE KEYS */;
INSERT INTO `routes` VALUES (1,'Nairobi East',10,'East',1,'2026-06-20 17:25:21');
/*!40000 ALTER TABLE `routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_items`
--

DROP TABLE IF EXISTS `sale_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sale_id` bigint NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `line_no` int NOT NULL DEFAULT '1',
  `item_code` varchar(50) DEFAULT NULL,
  `quantity` float NOT NULL,
  `uom` varchar(45) DEFAULT NULL,
  `selling_price` float NOT NULL,
  `discount_given` float NOT NULL DEFAULT '0',
  `product_vat` float NOT NULL DEFAULT '0',
  `amount` float NOT NULL,
  `on_wholesale_retail` int DEFAULT '0',
  `created_at` date DEFAULT (curdate()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sale_line` (`sale_id`,`line_no`),
  KEY `idx_sale_id` (`sale_id`),
  KEY `idx_product_code` (`product_code`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_items`
--

LOCK TABLES `sale_items` WRITE;
/*!40000 ALTER TABLE `sale_items` DISABLE KEYS */;
INSERT INTO `sale_items` VALUES (1,1,'6161100100015',1,'1',10,'kg',125,0,0,1250,1,'2026-06-20'),(2,2,'6161100100015',1,'1',20,'kg',125,0,0,2500,1,'2026-06-20'),(3,3,'6161100100015',1,'1',10,'kg',125,0,0,1250,1,'2026-06-20');
/*!40000 ALTER TABLE `sale_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_payments`
--

DROP TABLE IF EXISTS `sale_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale_payments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sale_id` bigint NOT NULL,
  `payment_method_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `payment_method_id` (`payment_method_id`),
  KEY `idx_sale_id` (`sale_id`),
  CONSTRAINT `sale_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_payments_ibfk_2` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_payments`
--

LOCK TABLES `sale_payments` WRITE;
/*!40000 ALTER TABLE `sale_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_num` int NOT NULL,
  `branch_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `channel` enum('pos','mobile','backend') NOT NULL DEFAULT 'pos',
  `order_source` enum('pos','mobile','backoffice','backend') NOT NULL DEFAULT 'backoffice',
  `payment_status` enum('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid',
  `amount_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `fulfillment_meta` json DEFAULT NULL,
  `till_id` int DEFAULT NULL,
  `float_session_id` bigint DEFAULT NULL,
  `cashier_id` int NOT NULL,
  `customer_num` int DEFAULT NULL,
  `customer_name_override` text,
  `route_id` int DEFAULT NULL,
  `required_date` date DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `status` enum('draft','held','booked','pending','unpaid','processed','pending_payment','paid','delivered','completed','cancelled') NOT NULL DEFAULT 'draft',
  `total_vat` float NOT NULL DEFAULT '0',
  `order_total` float NOT NULL DEFAULT '0',
  `order_discount` double NOT NULL DEFAULT '0',
  `voucher_payment_amount` double NOT NULL DEFAULT '0',
  `points_payment_amount` double NOT NULL DEFAULT '0',
  `loyalty_card_id` bigint DEFAULT NULL,
  `cash` int NOT NULL DEFAULT '0',
  `mpesa_amount` int DEFAULT '0',
  `equity_amount` int DEFAULT '0',
  `kcb_amount` int DEFAULT '0',
  `order_change` int NOT NULL DEFAULT '0',
  `payment_method_code` varchar(45) DEFAULT 'CASH',
  `is_credit_sale` tinyint DEFAULT '0',
  `stock_balanced` int DEFAULT '0',
  `receipt_printed` int DEFAULT '0',
  `comments` text,
  `archived` tinyint DEFAULT '0',
  `deleted_by` int DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancelled_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_num` (`order_num`),
  KEY `organization_id` (`organization_id`),
  KEY `till_id` (`till_id`),
  KEY `float_session_id` (`float_session_id`),
  KEY `cancelled_by` (`cancelled_by`),
  KEY `deleted_by` (`deleted_by`),
  KEY `idx_order_num` (`order_num`),
  KEY `idx_branch_id` (`branch_id`),
  KEY `idx_channel` (`channel`),
  KEY `idx_status` (`status`),
  KEY `idx_cashier_id` (`cashier_id`),
  KEY `idx_customer_num` (`customer_num`),
  KEY `idx_archived` (`archived`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_completed_at` (`completed_at`),
  KEY `idx_payment_status` (`payment_status`),
  KEY `sales_route_id_foreign` (`route_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `sales_ibfk_3` FOREIGN KEY (`till_id`) REFERENCES `tills` (`id`),
  CONSTRAINT `sales_ibfk_4` FOREIGN KEY (`float_session_id`) REFERENCES `till_float_sessions` (`id`),
  CONSTRAINT `sales_ibfk_5` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`id`),
  CONSTRAINT `sales_ibfk_6` FOREIGN KEY (`customer_num`) REFERENCES `customers` (`customer_num`),
  CONSTRAINT `sales_ibfk_8` FOREIGN KEY (`cancelled_by`) REFERENCES `users` (`id`),
  CONSTRAINT `sales_ibfk_9` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  CONSTRAINT `sales_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,1,1,1,'pos','backoffice','paid',1250.00,NULL,1,1,1,NULL,'Walk-in Customer',NULL,NULL,NULL,'completed',0,1250,0,0,0,NULL,1250,0,0,0,0,'CASH',0,0,0,NULL,0,NULL,NULL,'2026-06-20 14:25:21','2026-06-20 14:25:21',NULL,NULL),(2,2,1,1,'mobile','backoffice','paid',2500.00,'{\"driver_id\": 1, \"vehicle_id\": 1}',NULL,NULL,1,5002,NULL,1,NULL,NULL,'completed',0,2500,0,0,0,NULL,0,0,0,0,0,'CASH',0,0,0,NULL,0,NULL,NULL,'2026-06-20 14:25:21','2026-06-20 14:25:21',NULL,NULL),(3,3,1,1,'mobile','backoffice','unpaid',0.00,'{\"driver_id\": 1, \"vehicle_id\": 1}',NULL,NULL,1,5002,NULL,1,NULL,NULL,'processed',0,1250,0,0,0,NULL,0,0,0,0,0,'CASH',0,0,0,NULL,0,NULL,NULL,'2026-06-20 14:25:21',NULL,NULL,NULL);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movement_history`
--

DROP TABLE IF EXISTS `stock_movement_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movement_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_code` varchar(200) NOT NULL,
  `branch_id` int NOT NULL,
  `quantity_moved` double NOT NULL,
  `from_location` enum('shop','store') NOT NULL,
  `to_location` enum('shop','store') NOT NULL,
  `moved_by` int NOT NULL,
  `move_status` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `moved_by` (`moved_by`),
  KEY `idx_product_code` (`product_code`),
  CONSTRAINT `stock_movement_history_ibfk_1` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`),
  CONSTRAINT `stock_movement_history_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `stock_movement_history_ibfk_3` FOREIGN KEY (`moved_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movement_history`
--

LOCK TABLES `stock_movement_history` WRITE;
/*!40000 ALTER TABLE `stock_movement_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_movement_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_receipts`
--

DROP TABLE IF EXISTS `stock_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_receipts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_code` varchar(200) NOT NULL,
  `branch_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `units_received` float NOT NULL,
  `stock_location` enum('shop','store') NOT NULL DEFAULT 'store',
  `invoice_number` varchar(45) DEFAULT NULL,
  `cost_price` float DEFAULT NULL,
  `received_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `organization_id` (`organization_id`),
  KEY `received_by` (`received_by`),
  KEY `idx_product_code` (`product_code`),
  CONSTRAINT `stock_receipts_ibfk_1` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`),
  CONSTRAINT `stock_receipts_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `stock_receipts_ibfk_3` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `stock_receipts_ibfk_4` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_receipts`
--

LOCK TABLES `stock_receipts` WRITE;
/*!40000 ALTER TABLE `stock_receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_reservations`
--

DROP TABLE IF EXISTS `stock_reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_reservations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `stock_location` enum('shop','store') NOT NULL DEFAULT 'shop',
  `quantity` float NOT NULL,
  `cart_id` int DEFAULT NULL,
  `cart_line_id` int DEFAULT NULL,
  `sale_id` bigint DEFAULT NULL,
  `reserved_by` int NOT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `released_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_code` (`product_code`),
  KEY `reserved_by` (`reserved_by`),
  KEY `idx_branch_product` (`branch_id`,`product_code`),
  KEY `idx_cart_id` (`cart_id`),
  KEY `idx_cart_line_id` (`cart_line_id`),
  KEY `idx_sale_id` (`sale_id`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `stock_reservations_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `stock_reservations_ibfk_2` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`),
  CONSTRAINT `stock_reservations_ibfk_3` FOREIGN KEY (`cart_id`) REFERENCES `temporary_carts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_reservations_ibfk_4` FOREIGN KEY (`cart_line_id`) REFERENCES `cart_lines` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_reservations_ibfk_5` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_reservations_ibfk_6` FOREIGN KEY (`reserved_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_reservations`
--

LOCK TABLES `stock_reservations` WRITE;
/*!40000 ALTER TABLE `stock_reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_take_lines`
--

DROP TABLE IF EXISTS `stock_take_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_take_lines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` int NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `stock_location` enum('shop','store') NOT NULL,
  `system_quantity` float NOT NULL DEFAULT '0',
  `counted_quantity` float NOT NULL DEFAULT '0',
  `variance` float GENERATED ALWAYS AS ((`counted_quantity` - `system_quantity`)) STORED,
  PRIMARY KEY (`id`),
  KEY `product_code` (`product_code`),
  KEY `idx_session` (`session_id`),
  CONSTRAINT `stock_take_lines_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `stock_take_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_take_lines_ibfk_2` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_take_lines`
--

LOCK TABLES `stock_take_lines` WRITE;
/*!40000 ALTER TABLE `stock_take_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_take_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_take_sessions`
--

DROP TABLE IF EXISTS `stock_take_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_take_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `session_code` varchar(50) NOT NULL,
  `status` enum('draft','in_progress','completed','cancelled') DEFAULT 'draft',
  `stock_location` enum('shop','store','both') NOT NULL DEFAULT 'both',
  `started_by` int NOT NULL,
  `completed_by` int DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `started_by` (`started_by`),
  KEY `completed_by` (`completed_by`),
  KEY `idx_branch_status` (`branch_id`,`status`),
  CONSTRAINT `stock_take_sessions_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `stock_take_sessions_ibfk_2` FOREIGN KEY (`started_by`) REFERENCES `users` (`id`),
  CONSTRAINT `stock_take_sessions_ibfk_3` FOREIGN KEY (`completed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_take_sessions`
--

LOCK TABLES `stock_take_sessions` WRITE;
/*!40000 ALTER TABLE `stock_take_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_take_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_categories`
--

DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL,
  `subcategory_name` varchar(200) NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_category_id` (`category_id`),
  CONSTRAINT `sub_categories_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `sub_categories_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_categories`
--

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
INSERT INTO `sub_categories` VALUES (1,1,'Sugar',1,'2026-06-20 17:25:21');
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_payments`
--

DROP TABLE IF EXISTS `supplier_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_payments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  `lpo_no` int DEFAULT NULL,
  `payment_method_id` int NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `manual_amount` tinyint(1) DEFAULT '0',
  `declared_payable` decimal(10,2) DEFAULT NULL,
  `amount_due_snapshot` decimal(10,2) DEFAULT NULL,
  `cheque_number` varchar(45) DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `date_paid` date NOT NULL,
  `paid_by` int NOT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `payment_method_id` (`payment_method_id`),
  KEY `paid_by` (`paid_by`),
  KEY `idx_org_supplier_date` (`organization_id`,`supplier_id`,`date_paid`),
  KEY `idx_lpo_no` (`lpo_no`),
  CONSTRAINT `supplier_payments_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `supplier_payments_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `supplier_payments_ibfk_3` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`),
  CONSTRAINT `supplier_payments_ibfk_4` FOREIGN KEY (`paid_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_payments`
--

LOCK TABLES `supplier_payments` WRITE;
/*!40000 ALTER TABLE `supplier_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_return_document_lines`
--

DROP TABLE IF EXISTS `supplier_return_document_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_return_document_lines` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document_id` bigint NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `product_name` varchar(200) DEFAULT NULL,
  `quantity` double NOT NULL,
  `package_type` enum('full_package','partial','pieces') NOT NULL DEFAULT 'partial',
  `package_type_label` varchar(100) DEFAULT NULL,
  `uom_label` varchar(45) DEFAULT NULL,
  `stock_location` enum('shop','store') NOT NULL DEFAULT 'store',
  `reason` text,
  `lpo_txn_id` bigint DEFAULT NULL,
  `stock_deduct_qty` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `document_id` (`document_id`),
  KEY `idx_srdl_product` (`product_code`),
  CONSTRAINT `supplier_return_document_lines_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `supplier_return_documents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_return_document_lines`
--

LOCK TABLES `supplier_return_document_lines` WRITE;
/*!40000 ALTER TABLE `supplier_return_document_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_return_document_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_return_documents`
--

DROP TABLE IF EXISTS `supplier_return_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_return_documents` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `source_type` enum('lpo','manual') NOT NULL DEFAULT 'manual',
  `lpo_no` int DEFAULT NULL,
  `supplier_invoice_no` varchar(100) DEFAULT NULL,
  `reason_scope` enum('order','per_product') NOT NULL DEFAULT 'order',
  `return_reason` text,
  `notes` text,
  `status` enum('pending_approval','approved','rejected') NOT NULL DEFAULT 'pending_approval',
  `returned_by` int NOT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejected_by` int DEFAULT NULL,
  `rejected_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_srd_org_status` (`organization_id`,`status`),
  KEY `idx_srd_supplier_lpo` (`supplier_id`,`lpo_no`),
  KEY `idx_srd_branch` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_return_documents`
--

LOCK TABLES `supplier_return_documents` WRITE;
/*!40000 ALTER TABLE `supplier_return_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_return_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier_returns`
--

DROP TABLE IF EXISTS `supplier_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_returns` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `supplier_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `product_code` varchar(200) NOT NULL,
  `quantity` float NOT NULL,
  `package_type` enum('full_package','partial','pieces') NOT NULL DEFAULT 'partial',
  `uom_label` varchar(45) DEFAULT NULL,
  `stock_location` enum('shop','store') NOT NULL DEFAULT 'store',
  `reason` text,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` bigint DEFAULT NULL,
  `returned_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `returned_by` (`returned_by`),
  KEY `idx_supplier_id` (`supplier_id`),
  KEY `idx_product_code` (`product_code`),
  CONSTRAINT `supplier_returns_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `supplier_returns_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `supplier_returns_ibfk_3` FOREIGN KEY (`product_code`) REFERENCES `products` (`product_code`),
  CONSTRAINT `supplier_returns_ibfk_4` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier_returns`
--

LOCK TABLES `supplier_returns` WRITE;
/*!40000 ALTER TABLE `supplier_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(50) NOT NULL,
  `supplier_name` varchar(200) NOT NULL,
  `contact_person` varchar(200) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `alternate_phone` varchar(45) DEFAULT NULL,
  `address` text,
  `town` varchar(100) DEFAULT NULL,
  `tax_pin` varchar(45) DEFAULT NULL,
  `additional_info` text,
  `contacts` json DEFAULT NULL,
  `organization_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` int DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `supplier_code` (`supplier_code`),
  KEY `created_by` (`created_by`),
  KEY `organization_id` (`organization_id`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `suppliers_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `suppliers_ibfk_2` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'SUP-001','Mumias Sugar Co.',NULL,NULL,'0711222333',NULL,NULL,NULL,NULL,NULL,'[{\"email\": \"accounts@mumias.co.ke\", \"label\": \"Accounts\", \"phone\": \"0711999000\"}]',1,1,1,'2026-06-20 14:25:21','2026-06-20 14:25:21',NULL,NULL);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int DEFAULT NULL,
  `allow_below_stock` int DEFAULT '0',
  `global_low_stock_threshold` decimal(10,2) DEFAULT NULL,
  `stock_alert_mode` enum('per_product','global','both') DEFAULT 'per_product',
  `mail_host` varchar(200) DEFAULT NULL,
  `mail_user` varchar(200) DEFAULT NULL,
  `mail_password` varchar(200) DEFAULT NULL,
  `mail_port` int DEFAULT NULL,
  `mail_from` varchar(200) DEFAULT NULL,
  `admin_email` varchar(200) DEFAULT NULL,
  `backup_folder_path` varchar(200) DEFAULT NULL,
  `customer_debtor_message` text,
  `mpesa_callback_url` varchar(350) DEFAULT NULL,
  `equity_callback_url` varchar(350) DEFAULT NULL,
  `kra_device_callback_url` varchar(250) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `organization_id` (`organization_id`),
  CONSTRAINT `system_settings_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,1,0,NULL,'per_product',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-20 14:25:21','2026-06-20 14:25:21');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temporary_carts`
--

DROP TABLE IF EXISTS `temporary_carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temporary_carts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `channel` enum('pos','mobile','backend') NOT NULL DEFAULT 'pos',
  `order_source` enum('pos','mobile','backoffice','backend') NOT NULL DEFAULT 'backoffice',
  `till_id` int DEFAULT NULL,
  `route_id` int DEFAULT NULL,
  `order_discount` double NOT NULL DEFAULT '0',
  `discount_voucher_id` bigint unsigned DEFAULT NULL,
  `payment_voucher_id` bigint DEFAULT NULL,
  `voucher_payment_amount` double NOT NULL DEFAULT '0',
  `loyalty_card_id` bigint DEFAULT NULL,
  `points_redeemed` double NOT NULL DEFAULT '0',
  `points_payment_amount` double NOT NULL DEFAULT '0',
  `mpesa_phone` varchar(45) DEFAULT NULL,
  `mpesa_payment_amount` double NOT NULL DEFAULT '0',
  `mpesa_transaction_code` varchar(45) DEFAULT NULL,
  `update_no` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `till_id` (`till_id`),
  KEY `idx_user_channel` (`user_id`,`channel`),
  KEY `temporary_carts_route_id_foreign` (`route_id`),
  CONSTRAINT `temporary_carts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `temporary_carts_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `temporary_carts_ibfk_3` FOREIGN KEY (`till_id`) REFERENCES `tills` (`id`),
  CONSTRAINT `temporary_carts_route_id_foreign` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temporary_carts`
--

LOCK TABLES `temporary_carts` WRITE;
/*!40000 ALTER TABLE `temporary_carts` DISABLE KEYS */;
/*!40000 ALTER TABLE `temporary_carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `till_float_sessions`
--

DROP TABLE IF EXISTS `till_float_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `till_float_sessions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `till_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `cashier_id` int NOT NULL,
  `handed_over_from` bigint DEFAULT NULL,
  `handed_over_at` timestamp NULL DEFAULT NULL,
  `session_date` date NOT NULL,
  `working_amount` int NOT NULL DEFAULT '0',
  `float_breakdown` json DEFAULT NULL,
  `cash_movements` json DEFAULT NULL,
  `closing_amount` decimal(10,2) DEFAULT NULL,
  `closing_denominations` json DEFAULT NULL,
  `expected_amount` decimal(10,2) DEFAULT NULL,
  `cash_sales` decimal(10,2) DEFAULT '0.00',
  `expenses_total` decimal(10,2) DEFAULT '0.00',
  `opened_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `status` enum('open','closed','suspended') DEFAULT 'open',
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `idx_till_id` (`till_id`),
  KEY `idx_cashier_id` (`cashier_id`),
  KEY `idx_session_date` (`session_date`),
  KEY `idx_status` (`status`),
  CONSTRAINT `till_float_sessions_ibfk_1` FOREIGN KEY (`till_id`) REFERENCES `tills` (`id`),
  CONSTRAINT `till_float_sessions_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `till_float_sessions_ibfk_3` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `till_float_sessions`
--

LOCK TABLES `till_float_sessions` WRITE;
/*!40000 ALTER TABLE `till_float_sessions` DISABLE KEYS */;
INSERT INTO `till_float_sessions` VALUES (1,1,1,1,NULL,NULL,'2026-06-20',5000,'{\"CASH\": 5000}',NULL,NULL,NULL,NULL,0.00,0.00,'2026-06-20 17:25:21',NULL,NULL,'open',NULL);
/*!40000 ALTER TABLE `till_float_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tills`
--

DROP TABLE IF EXISTS `tills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tills` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `till_number` varchar(200) NOT NULL,
  `till_name` varchar(200) DEFAULT NULL,
  `description` text,
  `is_active` tinyint(1) DEFAULT '1',
  `ip_address` varchar(45) DEFAULT NULL,
  `cashier_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `idx_branch_id` (`branch_id`),
  KEY `idx_cashier_id` (`cashier_id`),
  CONSTRAINT `tills_cashier_id_foreign` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`id`),
  CONSTRAINT `tills_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tills`
--

LOCK TABLES `tills` WRITE;
/*!40000 ALTER TABLE `tills` DISABLE KEYS */;
INSERT INTO `tills` VALUES (1,1,'TILL-01',NULL,NULL,1,NULL,1,'2026-06-20 14:25:21','2026-06-20 14:25:21');
/*!40000 ALTER TABLE `tills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uoms`
--

DROP TABLE IF EXISTS `uoms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `uoms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversion_factor` float NOT NULL DEFAULT '1',
  `full_name` varchar(200) NOT NULL,
  `measure_name` varchar(120) DEFAULT NULL,
  `small_packaging_label` varchar(45) DEFAULT NULL,
  `middle_packaging_label` varchar(45) DEFAULT NULL,
  `middle_factor` float DEFAULT NULL,
  `uom_type` varchar(45) NOT NULL,
  `is_base_unit` tinyint(1) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `deleted_by` int DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `deleted_by` (`deleted_by`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `uoms_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `uoms_ibfk_2` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uoms`
--

LOCK TABLES `uoms` WRITE;
/*!40000 ALTER TABLE `uoms` DISABLE KEYS */;
INSERT INTO `uoms` VALUES (1,1,'Kilogram',NULL,NULL,NULL,NULL,'kg',1,1,1,NULL,NULL,'2026-06-20 17:25:21');
/*!40000 ALTER TABLE `uoms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_memberships`
--

DROP TABLE IF EXISTS `user_memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_memberships` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `role_id` int NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_scope` enum('org','branch') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'branch',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_membership_org_username` (`organization_id`,`username`),
  UNIQUE KEY `uq_user_org_membership` (`user_id`,`organization_id`),
  KEY `user_memberships_branch_id_foreign` (`branch_id`),
  KEY `user_memberships_role_id_foreign` (`role_id`),
  CONSTRAINT `user_memberships_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_memberships_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_memberships_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `user_memberships_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_memberships`
--

LOCK TABLES `user_memberships` WRITE;
/*!40000 ALTER TABLE `user_memberships` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_password_resets`
--

DROP TABLE IF EXISTS `user_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_password_resets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `organization_id` int NOT NULL,
  `token_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_password_resets_user_id_foreign` (`user_id`),
  KEY `user_password_resets_organization_id_token_hash_index` (`organization_id`,`token_hash`),
  CONSTRAINT `user_password_resets_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_password_resets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_password_resets`
--

LOCK TABLES `user_password_resets` WRITE;
/*!40000 ALTER TABLE `user_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permission_overrides`
--

DROP TABLE IF EXISTS `user_permission_overrides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_permission_overrides` (
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  `effect` enum('grant','deny') NOT NULL,
  PRIMARY KEY (`user_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `user_permission_overrides_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permission_overrides_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permission_overrides`
--

LOCK TABLES `user_permission_overrides` WRITE;
/*!40000 ALTER TABLE `user_permission_overrides` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_permission_overrides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `role_id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `is_admin` tinyint DEFAULT '0',
  `access_scope` enum('org','branch') NOT NULL DEFAULT 'org',
  `is_super_admin` tinyint DEFAULT '0',
  `is_mobile_user` tinyint DEFAULT '0',
  `login_channels` json DEFAULT NULL,
  `mobile_order_scope` enum('route_only','normal_only','both') DEFAULT 'both',
  `assigned_route_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_by` int DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_username` (`organization_id`,`username`),
  KEY `branch_id` (`branch_id`),
  KEY `role_id` (`role_id`),
  KEY `deleted_by` (`deleted_by`),
  KEY `idx_username` (`username`),
  KEY `idx_is_mobile` (`is_mobile_user`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `users_ibfk_3` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `users_ibfk_4` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,1,1,'admin','admin@demo.co.ke','$2y$12$OWCL2nxTbMeEmD4As4zAj.VCyX1Qr2lTqfiboIJpYjG4lk3GX.t7W','Demo Organization Manager',1,'org',0,0,'[\"backoffice\", \"pos\", \"mobile\"]','both',NULL,1,'2026-06-20 14:25:36','2026-06-20 14:25:20','2026-06-20 14:25:36',NULL,NULL),(2,1,1,2,'cashier',NULL,'$2y$12$hoBpl0oEqhon//oXu51Jhuik4SkQDqvy1HjPYQKodLtRCSAmElMfy','Peter Otieno',0,'branch',0,0,'[\"pos\", \"backoffice\"]','both',NULL,1,NULL,'2026-06-20 14:25:21','2026-06-20 14:25:21',NULL,NULL),(3,2,2,9,'superadmin','alpacke.tech@gmail.com','$2y$12$d9tAXFMd0x46ltYHOpz3IeXmvrE4xpdG7HlqChNZ1lY4Kzffb0kcC','Platform Super Admin',0,'org',1,0,'[\"backoffice\"]','both',NULL,1,NULL,'2026-06-20 14:25:21','2026-06-20 14:25:21',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_accounts_receivable_summary`
--

DROP TABLE IF EXISTS `v_accounts_receivable_summary`;
/*!50001 DROP VIEW IF EXISTS `v_accounts_receivable_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_accounts_receivable_summary` AS SELECT 
 1 AS `customer_num`,
 1 AS `customer_name`,
 1 AS `phone_number`,
 1 AS `route_name`,
 1 AS `customer_balance`,
 1 AS `invoice_balance_due`,
 1 AS `open_invoices`,
 1 AS `credit_sales_outstanding`,
 1 AS `total_outstanding`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_ar_aging`
--

DROP TABLE IF EXISTS `v_ar_aging`;
/*!50001 DROP VIEW IF EXISTS `v_ar_aging`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_ar_aging` AS SELECT 
 1 AS `customer_num`,
 1 AS `customer_name`,
 1 AS `phone_number`,
 1 AS `invoice_number`,
 1 AS `invoice_date`,
 1 AS `due_date`,
 1 AS `invoice_total`,
 1 AS `amount_paid`,
 1 AS `balance_due`,
 1 AS `payment_status`,
 1 AS `days_outstanding`,
 1 AS `aging_bucket`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_bank_transfer_report`
--

DROP TABLE IF EXISTS `v_bank_transfer_report`;
/*!50001 DROP VIEW IF EXISTS `v_bank_transfer_report`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_bank_transfer_report` AS SELECT 
 1 AS `organization_id`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `payroll_run_id`,
 1 AS `period_code`,
 1 AS `period_start`,
 1 AS `period_end`,
 1 AS `run_date`,
 1 AS `payroll_status`,
 1 AS `employee_id`,
 1 AS `employee_code`,
 1 AS `full_name`,
 1 AS `bank_name`,
 1 AS `bank_branch`,
 1 AS `account_number`,
 1 AS `account_name`,
 1 AS `payment_method`,
 1 AS `net_pay`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_category_sales`
--

DROP TABLE IF EXISTS `v_category_sales`;
/*!50001 DROP VIEW IF EXISTS `v_category_sales`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_category_sales` AS SELECT 
 1 AS `sale_date`,
 1 AS `branch_id`,
 1 AS `category_id`,
 1 AS `category_name`,
 1 AS `sub_category_id`,
 1 AS `subcategory_name`,
 1 AS `qty_sold`,
 1 AS `revenue`,
 1 AS `vat`,
 1 AS `discounts`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_contract_expiry`
--

DROP TABLE IF EXISTS `v_contract_expiry`;
/*!50001 DROP VIEW IF EXISTS `v_contract_expiry`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_contract_expiry` AS SELECT 
 1 AS `organization_id`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `employee_id`,
 1 AS `employee_code`,
 1 AS `full_name`,
 1 AS `employment_type`,
 1 AS `employment_status`,
 1 AS `contract_start_date`,
 1 AS `contract_end_date`,
 1 AS `days_until_expiry`,
 1 AS `department_name`,
 1 AS `job_title`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_credit_outstanding`
--

DROP TABLE IF EXISTS `v_credit_outstanding`;
/*!50001 DROP VIEW IF EXISTS `v_credit_outstanding`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_credit_outstanding` AS SELECT 
 1 AS `sale_id`,
 1 AS `order_num`,
 1 AS `branch_id`,
 1 AS `channel`,
 1 AS `customer_num`,
 1 AS `customer_name`,
 1 AS `status`,
 1 AS `payment_status`,
 1 AS `order_total`,
 1 AS `amount_paid`,
 1 AS `balance_due`,
 1 AS `created_at`,
 1 AS `completed_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_daily_sales`
--

DROP TABLE IF EXISTS `v_daily_sales`;
/*!50001 DROP VIEW IF EXISTS `v_daily_sales`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_daily_sales` AS SELECT 
 1 AS `sale_day`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `channel`,
 1 AS `orders`,
 1 AS `gross`,
 1 AS `vat`,
 1 AS `net`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_damages_summary`
--

DROP TABLE IF EXISTS `v_damages_summary`;
/*!50001 DROP VIEW IF EXISTS `v_damages_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_damages_summary` AS SELECT 
 1 AS `damage_date`,
 1 AS `branch_id`,
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `stock_location`,
 1 AS `package_type`,
 1 AS `total_qty`,
 1 AS `incident_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_discount_summary`
--

DROP TABLE IF EXISTS `v_discount_summary`;
/*!50001 DROP VIEW IF EXISTS `v_discount_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_discount_summary` AS SELECT 
 1 AS `sale_date`,
 1 AS `branch_id`,
 1 AS `channel`,
 1 AS `orders_with_discount`,
 1 AS `total_discount`,
 1 AS `net_line_sales`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_dispatch_trips_summary`
--

DROP TABLE IF EXISTS `v_dispatch_trips_summary`;
/*!50001 DROP VIEW IF EXISTS `v_dispatch_trips_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_dispatch_trips_summary` AS SELECT 
 1 AS `branch_id`,
 1 AS `scheduled_date`,
 1 AS `trip_code`,
 1 AS `route_name`,
 1 AS `driver_name`,
 1 AS `vehicle_plate`,
 1 AS `status`,
 1 AS `order_count`,
 1 AS `expected_cash`,
 1 AS `collected_cash`,
 1 AS `cash_variance`,
 1 AS `departed_at`,
 1 AS `completed_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_driver_deliveries`
--

DROP TABLE IF EXISTS `v_driver_deliveries`;
/*!50001 DROP VIEW IF EXISTS `v_driver_deliveries`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_driver_deliveries` AS SELECT 
 1 AS `branch_id`,
 1 AS `delivery_date`,
 1 AS `driver_name`,
 1 AS `route_name`,
 1 AS `deliveries`,
 1 AS `total_value`,
 1 AS `cash_value`,
 1 AS `credit_value`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_eod_cashier_summary`
--

DROP TABLE IF EXISTS `v_eod_cashier_summary`;
/*!50001 DROP VIEW IF EXISTS `v_eod_cashier_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_eod_cashier_summary` AS SELECT 
 1 AS `sale_date`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `cashier_id`,
 1 AS `cashier`,
 1 AS `total_transactions`,
 1 AS `gross_sales`,
 1 AS `total_vat`,
 1 AS `cash_collected`,
 1 AS `mpesa_collected`,
 1 AS `equity_collected`,
 1 AS `kcb_collected`,
 1 AS `net_sales`,
 1 AS `opening_float`,
 1 AS `float_breakdown_json`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_expenses_summary`
--

DROP TABLE IF EXISTS `v_expenses_summary`;
/*!50001 DROP VIEW IF EXISTS `v_expenses_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_expenses_summary` AS SELECT 
 1 AS `expense_date`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `expense_group_id`,
 1 AS `group_name`,
 1 AS `expense_count`,
 1 AS `total_amount`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_headcount_report`
--

DROP TABLE IF EXISTS `v_headcount_report`;
/*!50001 DROP VIEW IF EXISTS `v_headcount_report`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_headcount_report` AS SELECT 
 1 AS `organization_id`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `department_id`,
 1 AS `department_name`,
 1 AS `employee_id`,
 1 AS `employee_code`,
 1 AS `full_name`,
 1 AS `employment_status`,
 1 AS `employment_type`,
 1 AS `job_title`,
 1 AS `hire_date`,
 1 AS `base_salary`,
 1 AS `is_active`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_hr_dashboard_kpi`
--

DROP TABLE IF EXISTS `v_hr_dashboard_kpi`;
/*!50001 DROP VIEW IF EXISTS `v_hr_dashboard_kpi`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_hr_dashboard_kpi` AS SELECT 
 1 AS `organization_id`,
 1 AS `total_employees`,
 1 AS `active_employees`,
 1 AS `department_count`,
 1 AS `monthly_base_payroll`,
 1 AS `contracts_expiring_90d`,
 1 AS `separated_employees`,
 1 AS `processed_payroll_runs`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_invoice_payment_history`
--

DROP TABLE IF EXISTS `v_invoice_payment_history`;
/*!50001 DROP VIEW IF EXISTS `v_invoice_payment_history`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_invoice_payment_history` AS SELECT 
 1 AS `payment_id`,
 1 AS `customer_num`,
 1 AS `customer_name`,
 1 AS `invoice_number`,
 1 AS `date_paid`,
 1 AS `amount_paid`,
 1 AS `method_name`,
 1 AS `received_by`,
 1 AS `reference_number`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_journal_register`
--

DROP TABLE IF EXISTS `v_journal_register`;
/*!50001 DROP VIEW IF EXISTS `v_journal_register`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_journal_register` AS SELECT 
 1 AS `journal_entry_id`,
 1 AS `organization_id`,
 1 AS `branch_id`,
 1 AS `entry_number`,
 1 AS `entry_date`,
 1 AS `reference_type`,
 1 AS `reference_id`,
 1 AS `status`,
 1 AS `description`,
 1 AS `total_debit`,
 1 AS `total_credit`,
 1 AS `created_by`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_kra_receipts`
--

DROP TABLE IF EXISTS `v_kra_receipts`;
/*!50001 DROP VIEW IF EXISTS `v_kra_receipts`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_kra_receipts` AS SELECT 
 1 AS `receipt_date`,
 1 AS `branch_id`,
 1 AS `channel`,
 1 AS `status`,
 1 AS `receipt_count`,
 1 AS `order_total`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_low_stock`
--

DROP TABLE IF EXISTS `v_low_stock`;
/*!50001 DROP VIEW IF EXISTS `v_low_stock`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_low_stock` AS SELECT 
 1 AS `branch_id`,
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `wholesale_price`,
 1 AS `uom_name`,
 1 AS `conversion_factor`,
 1 AS `shop_quantity`,
 1 AS `store_quantity`,
 1 AS `total_base_units`,
 1 AS `reorder_point`,
 1 AS `low_stock_alert_enabled`,
 1 AS `product_alert`,
 1 AS `max_qty_measure`,
 1 AS `markup_price`,
 1 AS `wholesale_markup_price`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_open_lpo_lines`
--

DROP TABLE IF EXISTS `v_open_lpo_lines`;
/*!50001 DROP VIEW IF EXISTS `v_open_lpo_lines`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_open_lpo_lines` AS SELECT 
 1 AS `lpo_no`,
 1 AS `supplier_id`,
 1 AS `supplier_name`,
 1 AS `lpo_status_code`,
 1 AS `status_name`,
 1 AS `due_date`,
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `ordered_qty`,
 1 AS `received_qty`,
 1 AS `pending_qty`,
 1 AS `cost_price`,
 1 AS `uom`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_payment_collection`
--

DROP TABLE IF EXISTS `v_payment_collection`;
/*!50001 DROP VIEW IF EXISTS `v_payment_collection`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_payment_collection` AS SELECT 
 1 AS `payment_date`,
 1 AS `branch_id`,
 1 AS `channel`,
 1 AS `method_code`,
 1 AS `method_name`,
 1 AS `payment_count`,
 1 AS `total_collected`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_payroll_summary`
--

DROP TABLE IF EXISTS `v_payroll_summary`;
/*!50001 DROP VIEW IF EXISTS `v_payroll_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_payroll_summary` AS SELECT 
 1 AS `payroll_run_id`,
 1 AS `organization_id`,
 1 AS `period_code`,
 1 AS `period_start`,
 1 AS `period_end`,
 1 AS `run_date`,
 1 AS `status`,
 1 AS `total_gross`,
 1 AS `total_net`,
 1 AS `employee_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_pod_compliance`
--

DROP TABLE IF EXISTS `v_pod_compliance`;
/*!50001 DROP VIEW IF EXISTS `v_pod_compliance`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_pod_compliance` AS SELECT 
 1 AS `branch_id`,
 1 AS `capture_date`,
 1 AS `route_name`,
 1 AS `driver_name`,
 1 AS `pod_count`,
 1 AS `complete_count`,
 1 AS `partial_count`,
 1 AS `refused_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_profit_loss_summary`
--

DROP TABLE IF EXISTS `v_profit_loss_summary`;
/*!50001 DROP VIEW IF EXISTS `v_profit_loss_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_profit_loss_summary` AS SELECT 
 1 AS `period`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `gross_revenue`,
 1 AS `vat_collected`,
 1 AS `net_revenue`,
 1 AS `cogs`,
 1 AS `gross_profit`,
 1 AS `total_expenses`,
 1 AS `net_profit`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_purchases_by_supplier`
--

DROP TABLE IF EXISTS `v_purchases_by_supplier`;
/*!50001 DROP VIEW IF EXISTS `v_purchases_by_supplier`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_purchases_by_supplier` AS SELECT 
 1 AS `supplier_id`,
 1 AS `supplier_name`,
 1 AS `lpo_no`,
 1 AS `order_date`,
 1 AS `due_date`,
 1 AS `total_amount`,
 1 AS `lpo_status_code`,
 1 AS `status_name`,
 1 AS `line_items`,
 1 AS `total_qty_ordered`,
 1 AS `total_qty_received`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_route_loading_summary`
--

DROP TABLE IF EXISTS `v_route_loading_summary`;
/*!50001 DROP VIEW IF EXISTS `v_route_loading_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_route_loading_summary` AS SELECT 
 1 AS `loading_date`,
 1 AS `route_name`,
 1 AS `channel`,
 1 AS `cashier_id`,
 1 AS `salesperson`,
 1 AS `total_orders`,
 1 AS `total_items`,
 1 AS `total_qty`,
 1 AS `total_value`,
 1 AS `grand_total`,
 1 AS `delivered_value`,
 1 AS `cash_collected`,
 1 AS `credit_outstanding`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_sales_by_channel`
--

DROP TABLE IF EXISTS `v_sales_by_channel`;
/*!50001 DROP VIEW IF EXISTS `v_sales_by_channel`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_sales_by_channel` AS SELECT 
 1 AS `sale_date`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `channel`,
 1 AS `payment_status`,
 1 AS `order_count`,
 1 AS `gross_sales`,
 1 AS `collected`,
 1 AS `total_vat`,
 1 AS `net_sales`,
 1 AS `credit_sales`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_sales_by_customer`
--

DROP TABLE IF EXISTS `v_sales_by_customer`;
/*!50001 DROP VIEW IF EXISTS `v_sales_by_customer`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_sales_by_customer` AS SELECT 
 1 AS `customer_num`,
 1 AS `customer_name`,
 1 AS `phone_number`,
 1 AS `route_name`,
 1 AS `total_orders`,
 1 AS `total_purchased`,
 1 AS `total_invoiced`,
 1 AS `total_paid`,
 1 AS `total_outstanding`,
 1 AS `ar_balance`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_sales_by_product`
--

DROP TABLE IF EXISTS `v_sales_by_product`;
/*!50001 DROP VIEW IF EXISTS `v_sales_by_product`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_sales_by_product` AS SELECT 
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `sale_date`,
 1 AS `branch_id`,
 1 AS `channel`,
 1 AS `qty_sold`,
 1 AS `sell_uom`,
 1 AS `total_revenue`,
 1 AS `total_vat`,
 1 AS `total_discount`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_sales_by_user`
--

DROP TABLE IF EXISTS `v_sales_by_user`;
/*!50001 DROP VIEW IF EXISTS `v_sales_by_user`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_sales_by_user` AS SELECT 
 1 AS `sale_date`,
 1 AS `branch_id`,
 1 AS `cashier_id`,
 1 AS `salesperson`,
 1 AS `channel`,
 1 AS `order_count`,
 1 AS `gross_sales`,
 1 AS `amount_collected`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_sales_pipeline`
--

DROP TABLE IF EXISTS `v_sales_pipeline`;
/*!50001 DROP VIEW IF EXISTS `v_sales_pipeline`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_sales_pipeline` AS SELECT 
 1 AS `order_date`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `channel`,
 1 AS `status`,
 1 AS `payment_status`,
 1 AS `order_count`,
 1 AS `pipeline_value`,
 1 AS `collected_so_far`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_staff_turnover`
--

DROP TABLE IF EXISTS `v_staff_turnover`;
/*!50001 DROP VIEW IF EXISTS `v_staff_turnover`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_staff_turnover` AS SELECT 
 1 AS `organization_id`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `department_id`,
 1 AS `department_name`,
 1 AS `active_employees`,
 1 AS `separated_employees`,
 1 AS `total_employees`,
 1 AS `turnover_rate_pct`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_statutory_deductions`
--

DROP TABLE IF EXISTS `v_statutory_deductions`;
/*!50001 DROP VIEW IF EXISTS `v_statutory_deductions`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_statutory_deductions` AS SELECT 
 1 AS `organization_id`,
 1 AS `branch_id`,
 1 AS `payroll_run_id`,
 1 AS `period_code`,
 1 AS `period_start`,
 1 AS `period_end`,
 1 AS `run_date`,
 1 AS `payroll_status`,
 1 AS `employee_id`,
 1 AS `employee_code`,
 1 AS `full_name`,
 1 AS `department_name`,
 1 AS `gross_pay`,
 1 AS `taxable_income`,
 1 AS `nssf`,
 1 AS `shif`,
 1 AS `housing_levy`,
 1 AS `paye`,
 1 AS `other_deductions`,
 1 AS `total_deductions`,
 1 AS `net_pay`,
 1 AS `employer_nssf`,
 1 AS `employer_housing`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_stock_chain`
--

DROP TABLE IF EXISTS `v_stock_chain`;
/*!50001 DROP VIEW IF EXISTS `v_stock_chain`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_stock_chain` AS SELECT 
 1 AS `branch_id`,
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `first_received_at`,
 1 AS `first_sold_at`,
 1 AS `last_movement_at`,
 1 AS `total_received`,
 1 AS `total_sold`,
 1 AS `current_shop_stock`,
 1 AS `current_store_stock`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_stock_on_hand`
--

DROP TABLE IF EXISTS `v_stock_on_hand`;
/*!50001 DROP VIEW IF EXISTS `v_stock_on_hand`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_stock_on_hand` AS SELECT 
 1 AS `branch_id`,
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `wholesale_price`,
 1 AS `uom_name`,
 1 AS `conversion_factor`,
 1 AS `shop_quantity`,
 1 AS `store_quantity`,
 1 AS `total_base_units`,
 1 AS `reorder_point`,
 1 AS `low_stock_alert_enabled`,
 1 AS `product_alert`,
 1 AS `max_qty_measure`,
 1 AS `markup_price`,
 1 AS `wholesale_markup_price`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_stock_receipts_detail`
--

DROP TABLE IF EXISTS `v_stock_receipts_detail`;
/*!50001 DROP VIEW IF EXISTS `v_stock_receipts_detail`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_stock_receipts_detail` AS SELECT 
 1 AS `receipt_date`,
 1 AS `branch_id`,
 1 AS `organization_id`,
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `units_received`,
 1 AS `stock_location`,
 1 AS `cost_price`,
 1 AS `line_cost`,
 1 AS `invoice_number`,
 1 AS `received_by`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_stock_reservations_active`
--

DROP TABLE IF EXISTS `v_stock_reservations_active`;
/*!50001 DROP VIEW IF EXISTS `v_stock_reservations_active`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_stock_reservations_active` AS SELECT 
 1 AS `branch_id`,
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `stock_location`,
 1 AS `reserved_qty`,
 1 AS `reservation_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_stock_transfers`
--

DROP TABLE IF EXISTS `v_stock_transfers`;
/*!50001 DROP VIEW IF EXISTS `v_stock_transfers`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_stock_transfers` AS SELECT 
 1 AS `transfer_date`,
 1 AS `branch_id`,
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `from_location`,
 1 AS `to_location`,
 1 AS `total_moved`,
 1 AS `transfer_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_stock_valuation`
--

DROP TABLE IF EXISTS `v_stock_valuation`;
/*!50001 DROP VIEW IF EXISTS `v_stock_valuation`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_stock_valuation` AS SELECT 
 1 AS `branch_id`,
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `shop_quantity`,
 1 AS `store_quantity`,
 1 AS `total_qty`,
 1 AS `last_cost_price`,
 1 AS `unit_price`,
 1 AS `cost_value`,
 1 AS `retail_value`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_supplier_payables`
--

DROP TABLE IF EXISTS `v_supplier_payables`;
/*!50001 DROP VIEW IF EXISTS `v_supplier_payables`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_supplier_payables` AS SELECT 
 1 AS `supplier_id`,
 1 AS `supplier_code`,
 1 AS `supplier_name`,
 1 AS `received_value`,
 1 AS `return_value`,
 1 AS `balance_due`,
 1 AS `open_lpo_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_supplier_returns_detail`
--

DROP TABLE IF EXISTS `v_supplier_returns_detail`;
/*!50001 DROP VIEW IF EXISTS `v_supplier_returns_detail`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_supplier_returns_detail` AS SELECT 
 1 AS `return_date`,
 1 AS `branch_id`,
 1 AS `supplier_id`,
 1 AS `supplier_name`,
 1 AS `product_code`,
 1 AS `product_name`,
 1 AS `quantity`,
 1 AS `stock_location`,
 1 AS `reason`,
 1 AS `returned_by`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_till_session_summary`
--

DROP TABLE IF EXISTS `v_till_session_summary`;
/*!50001 DROP VIEW IF EXISTS `v_till_session_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_till_session_summary` AS SELECT 
 1 AS `session_id`,
 1 AS `session_date`,
 1 AS `branch_id`,
 1 AS `till_id`,
 1 AS `till_number`,
 1 AS `cashier_id`,
 1 AS `cashier`,
 1 AS `status`,
 1 AS `opening_float`,
 1 AS `closing_amount`,
 1 AS `expected_amount`,
 1 AS `cash_sales`,
 1 AS `completed_sales`,
 1 AS `gross_sales`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_top_debtors`
--

DROP TABLE IF EXISTS `v_top_debtors`;
/*!50001 DROP VIEW IF EXISTS `v_top_debtors`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_top_debtors` AS SELECT 
 1 AS `customer_num`,
 1 AS `customer_name`,
 1 AS `phone_number`,
 1 AS `route_name`,
 1 AS `current_balance`,
 1 AS `open_invoices`,
 1 AS `invoice_balance`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_trip_cash_settlement`
--

DROP TABLE IF EXISTS `v_trip_cash_settlement`;
/*!50001 DROP VIEW IF EXISTS `v_trip_cash_settlement`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_trip_cash_settlement` AS SELECT 
 1 AS `branch_id`,
 1 AS `scheduled_date`,
 1 AS `trip_code`,
 1 AS `route_name`,
 1 AS `driver_name`,
 1 AS `expected_cash`,
 1 AS `collected_cash`,
 1 AS `cash_variance`,
 1 AS `status`,
 1 AS `settled_at`,
 1 AS `settled_by`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_vat_collected`
--

DROP TABLE IF EXISTS `v_vat_collected`;
/*!50001 DROP VIEW IF EXISTS `v_vat_collected`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_vat_collected` AS SELECT 
 1 AS `sale_date`,
 1 AS `branch_id`,
 1 AS `branch_name`,
 1 AS `channel`,
 1 AS `vat_collected`,
 1 AS `gross_sales`,
 1 AS `orders`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vats`
--

DROP TABLE IF EXISTS `vats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vat_code` varchar(20) NOT NULL,
  `vat_name` varchar(100) NOT NULL,
  `vat_percentage` decimal(5,2) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vat_code` (`vat_code`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `vats_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vats`
--

LOCK TABLES `vats` WRITE;
/*!40000 ALTER TABLE `vats` DISABLE KEYS */;
INSERT INTO `vats` VALUES (1,'V','Standard Rated',16.00,1,1,'2026-06-20 17:25:21');
/*!40000 ALTER TABLE `vats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicles`
--

DROP TABLE IF EXISTS `vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int NOT NULL,
  `vehicle_code` varchar(45) NOT NULL,
  `vehicle_name` varchar(200) NOT NULL,
  `plate_number` varchar(45) DEFAULT NULL,
  `max_weight_kg` decimal(10,2) DEFAULT NULL,
  `max_volume_m3` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_branch_vehicle` (`branch_id`,`vehicle_code`),
  CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicles`
--

LOCK TABLES `vehicles` WRITE;
/*!40000 ALTER TABLE `vehicles` DISABLE KEYS */;
INSERT INTO `vehicles` VALUES (1,1,'KCA-123A','Delivery Van 1','KCA 123A',NULL,NULL,1,'2026-06-20 17:25:21');
/*!40000 ALTER TABLE `vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vouchers`
--

DROP TABLE IF EXISTS `vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vouchers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `voucher_code` varchar(50) NOT NULL,
  `voucher_kind` enum('discount','payment') NOT NULL DEFAULT 'discount',
  `name` varchar(200) DEFAULT NULL,
  `description` text,
  `discount_type` enum('fixed','percentage') NOT NULL DEFAULT 'fixed',
  `discount_value` double NOT NULL DEFAULT '0',
  `initial_balance` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `min_order_amount` double NOT NULL DEFAULT '0',
  `max_redemptions` int DEFAULT NULL,
  `redemption_count` int NOT NULL DEFAULT '0',
  `valid_from` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_voucher_code` (`organization_id`,`voucher_code`),
  KEY `created_by` (`created_by`),
  KEY `idx_vouchers_org_active` (`organization_id`,`is_active`),
  CONSTRAINT `vouchers_ibfk_1` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`),
  CONSTRAINT `vouchers_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_shifts`
--

DROP TABLE IF EXISTS `work_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_shifts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` int NOT NULL,
  `shift_code` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shift_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `crosses_midnight` tinyint(1) NOT NULL DEFAULT '0',
  `works_saturday` tinyint(1) NOT NULL DEFAULT '0',
  `works_sunday` tinyint(1) NOT NULL DEFAULT '0',
  `works_public_holidays` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_shift_code` (`organization_id`,`shift_code`),
  CONSTRAINT `work_shifts_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_shifts`
--

LOCK TABLES `work_shifts` WRITE;
/*!40000 ALTER TABLE `work_shifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `work_shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pos_erp'
--

--
-- Final view structure for view `v_accounts_receivable_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_accounts_receivable_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_accounts_receivable_summary` AS select `c`.`customer_num` AS `customer_num`,`c`.`customer_name` AS `customer_name`,`c`.`phone_number` AS `phone_number`,`r`.`route_name` AS `route_name`,coalesce(`c`.`current_balance`,0) AS `customer_balance`,coalesce(`inv`.`open_invoice_total`,0) AS `invoice_balance_due`,coalesce(`inv`.`open_invoice_count`,0) AS `open_invoices`,coalesce(`credit`.`credit_sales_outstanding`,0) AS `credit_sales_outstanding`,((coalesce(`c`.`current_balance`,0) + coalesce(`inv`.`open_invoice_total`,0)) + coalesce(`credit`.`credit_sales_outstanding`,0)) AS `total_outstanding` from (((`customers` `c` left join `routes` `r` on((`c`.`route_id` = `r`.`id`))) left join (select `ci`.`customer_num` AS `customer_num`,sum(`ci`.`balance_due`) AS `open_invoice_total`,count(0) AS `open_invoice_count` from `customer_invoices` `ci` where ((`ci`.`payment_status` in (0,1)) and (`ci`.`deleted_at` is null)) group by `ci`.`customer_num`) `inv` on((`inv`.`customer_num` = `c`.`customer_num`))) left join (select `s`.`customer_num` AS `customer_num`,sum((`s`.`order_total` - `s`.`amount_paid`)) AS `credit_sales_outstanding` from `sales` `s` where ((`s`.`status` = 'completed') and (`s`.`is_credit_sale` = 1) and (`s`.`payment_status` in ('unpaid','partial')) and (`s`.`customer_num` is not null)) group by `s`.`customer_num`) `credit` on((`credit`.`customer_num` = `c`.`customer_num`))) where ((`c`.`deleted_at` is null) and ((coalesce(`c`.`current_balance`,0) > 0) or (coalesce(`inv`.`open_invoice_total`,0) > 0) or (coalesce(`credit`.`credit_sales_outstanding`,0) > 0))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_ar_aging`
--

/*!50001 DROP VIEW IF EXISTS `v_ar_aging`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_ar_aging` AS select `ci`.`customer_num` AS `customer_num`,`c`.`customer_name` AS `customer_name`,`c`.`phone_number` AS `phone_number`,`ci`.`invoice_number` AS `invoice_number`,`ci`.`invoice_date` AS `invoice_date`,`ci`.`due_date` AS `due_date`,`ci`.`invoice_total` AS `invoice_total`,`ci`.`amount_paid` AS `amount_paid`,`ci`.`balance_due` AS `balance_due`,`ci`.`payment_status` AS `payment_status`,(to_days(curdate()) - to_days(`ci`.`invoice_date`)) AS `days_outstanding`,(case when ((to_days(curdate()) - to_days(`ci`.`invoice_date`)) <= 30) then '0-30 days' when ((to_days(curdate()) - to_days(`ci`.`invoice_date`)) <= 60) then '31-60 days' when ((to_days(curdate()) - to_days(`ci`.`invoice_date`)) <= 90) then '61-90 days' else 'Over 90 days' end) AS `aging_bucket` from (`customer_invoices` `ci` join `customers` `c` on((`ci`.`customer_num` = `c`.`customer_num`))) where ((`ci`.`payment_status` in (0,1)) and (`ci`.`deleted_at` is null)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_bank_transfer_report`
--

/*!50001 DROP VIEW IF EXISTS `v_bank_transfer_report`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_bank_transfer_report` AS select `e`.`organization_id` AS `organization_id`,`e`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,`pr`.`id` AS `payroll_run_id`,`pp`.`period_code` AS `period_code`,`pp`.`period_start` AS `period_start`,`pp`.`period_end` AS `period_end`,`pr`.`run_date` AS `run_date`,`pr`.`status` AS `payroll_status`,`e`.`id` AS `employee_id`,`e`.`employee_code` AS `employee_code`,`e`.`full_name` AS `full_name`,`eba`.`bank_name` AS `bank_name`,`eba`.`bank_branch` AS `bank_branch`,`eba`.`account_number` AS `account_number`,`eba`.`account_name` AS `account_name`,`eba`.`payment_method` AS `payment_method`,`pl`.`net_pay` AS `net_pay` from (((((`payroll_lines` `pl` join `payroll_runs` `pr` on((`pl`.`payroll_run_id` = `pr`.`id`))) join `pay_periods` `pp` on((`pr`.`pay_period_id` = `pp`.`id`))) join `employees` `e` on((`pl`.`employee_id` = `e`.`id`))) join `employee_bank_accounts` `eba` on(((`eba`.`employee_id` = `e`.`id`) and (`eba`.`is_primary` = 1)))) left join `branches` `b` on((`e`.`branch_id` = `b`.`id`))) where ((`eba`.`payment_method` = 'bank_transfer') and (`pl`.`net_pay` > 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_category_sales`
--

/*!50001 DROP VIEW IF EXISTS `v_category_sales`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_category_sales` AS select cast(`s`.`completed_at` as date) AS `sale_date`,`s`.`branch_id` AS `branch_id`,`c`.`id` AS `category_id`,`c`.`category_name` AS `category_name`,`sc`.`id` AS `sub_category_id`,`sc`.`subcategory_name` AS `subcategory_name`,sum(`si`.`quantity`) AS `qty_sold`,sum(`si`.`amount`) AS `revenue`,sum(`si`.`product_vat`) AS `vat`,sum(`si`.`discount_given`) AS `discounts` from ((((`sale_items` `si` join `sales` `s` on((`si`.`sale_id` = `s`.`id`))) join `products` `p` on((`si`.`product_code` = `p`.`product_code`))) join `sub_categories` `sc` on((`p`.`subcategory_id` = `sc`.`id`))) join `categories` `c` on((`sc`.`category_id` = `c`.`id`))) where (`s`.`status` = 'completed') group by cast(`s`.`completed_at` as date),`s`.`branch_id`,`c`.`id`,`sc`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_contract_expiry`
--

/*!50001 DROP VIEW IF EXISTS `v_contract_expiry`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_contract_expiry` AS select `e`.`organization_id` AS `organization_id`,`e`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,`e`.`id` AS `employee_id`,`e`.`employee_code` AS `employee_code`,`e`.`full_name` AS `full_name`,`e`.`employment_type` AS `employment_type`,`e`.`employment_status` AS `employment_status`,`e`.`contract_start_date` AS `contract_start_date`,`e`.`contract_end_date` AS `contract_end_date`,(to_days(`e`.`contract_end_date`) - to_days(curdate())) AS `days_until_expiry`,`d`.`department_name` AS `department_name`,`e`.`job_title` AS `job_title` from ((`employees` `e` left join `departments` `d` on((`e`.`department_id` = `d`.`id`))) left join `branches` `b` on((`e`.`branch_id` = `b`.`id`))) where ((`e`.`contract_end_date` is not null) and (`e`.`employment_status` = 'active')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_credit_outstanding`
--

/*!50001 DROP VIEW IF EXISTS `v_credit_outstanding`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_credit_outstanding` AS select `s`.`id` AS `sale_id`,`s`.`order_num` AS `order_num`,`s`.`branch_id` AS `branch_id`,`s`.`channel` AS `channel`,`s`.`customer_num` AS `customer_num`,coalesce(`c`.`customer_name`,`s`.`customer_name_override`) AS `customer_name`,`s`.`status` AS `status`,`s`.`payment_status` AS `payment_status`,`s`.`order_total` AS `order_total`,`s`.`amount_paid` AS `amount_paid`,(`s`.`order_total` - `s`.`amount_paid`) AS `balance_due`,`s`.`created_at` AS `created_at`,`s`.`completed_at` AS `completed_at` from (`sales` `s` left join `customers` `c` on((`s`.`customer_num` = `c`.`customer_num`))) where ((`s`.`is_credit_sale` = 1) and (`s`.`payment_status` in ('unpaid','partial')) and (`s`.`status` <> 'cancelled') and (`s`.`archived` = 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_daily_sales`
--

/*!50001 DROP VIEW IF EXISTS `v_daily_sales`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_daily_sales` AS select cast(`s`.`completed_at` as date) AS `sale_day`,`s`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,`s`.`channel` AS `channel`,count(0) AS `orders`,sum(`s`.`order_total`) AS `gross`,sum(`s`.`total_vat`) AS `vat`,sum((`s`.`order_total` - `s`.`total_vat`)) AS `net` from (`sales` `s` join `branches` `b` on((`s`.`branch_id` = `b`.`id`))) where ((`s`.`status` = 'completed') and (`s`.`archived` = 0)) group by cast(`s`.`completed_at` as date),`s`.`branch_id`,`s`.`channel` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_damages_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_damages_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_damages_summary` AS select cast(`d`.`created_at` as date) AS `damage_date`,`d`.`branch_id` AS `branch_id`,`d`.`product_code` AS `product_code`,`p`.`product_name` AS `product_name`,`d`.`stock_location` AS `stock_location`,`d`.`package_type` AS `package_type`,sum(`d`.`quantity`) AS `total_qty`,count(0) AS `incident_count` from (`damages` `d` join `products` `p` on((`d`.`product_code` = `p`.`product_code`))) group by cast(`d`.`created_at` as date),`d`.`branch_id`,`d`.`product_code`,`p`.`product_name`,`d`.`stock_location`,`d`.`package_type` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_discount_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_discount_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_discount_summary` AS select cast(`s`.`completed_at` as date) AS `sale_date`,`s`.`branch_id` AS `branch_id`,`s`.`channel` AS `channel`,count(distinct `s`.`id`) AS `orders_with_discount`,sum(`si`.`discount_given`) AS `total_discount`,sum(`si`.`amount`) AS `net_line_sales` from (`sale_items` `si` join `sales` `s` on((`si`.`sale_id` = `s`.`id`))) where ((`s`.`status` = 'completed') and (`si`.`discount_given` > 0)) group by cast(`s`.`completed_at` as date),`s`.`branch_id`,`s`.`channel` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_dispatch_trips_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_dispatch_trips_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_dispatch_trips_summary` AS select `dt`.`branch_id` AS `branch_id`,`dt`.`scheduled_date` AS `scheduled_date`,`dt`.`trip_code` AS `trip_code`,`r`.`route_name` AS `route_name`,`d`.`full_name` AS `driver_name`,`v`.`plate_number` AS `vehicle_plate`,`dt`.`status` AS `status`,count(distinct `dts`.`sale_id`) AS `order_count`,`dt`.`expected_cash` AS `expected_cash`,`dt`.`collected_cash` AS `collected_cash`,`dt`.`cash_variance` AS `cash_variance`,`dt`.`departed_at` AS `departed_at`,`dt`.`completed_at` AS `completed_at` from ((((`dispatch_trips` `dt` left join `routes` `r` on((`dt`.`route_id` = `r`.`id`))) left join `drivers` `d` on((`dt`.`driver_id` = `d`.`id`))) left join `vehicles` `v` on((`dt`.`vehicle_id` = `v`.`id`))) left join `dispatch_trip_sales` `dts` on((`dts`.`trip_id` = `dt`.`id`))) group by `dt`.`id`,`dt`.`branch_id`,`dt`.`scheduled_date`,`dt`.`trip_code`,`r`.`route_name`,`d`.`full_name`,`v`.`plate_number`,`dt`.`status`,`dt`.`expected_cash`,`dt`.`collected_cash`,`dt`.`cash_variance`,`dt`.`departed_at`,`dt`.`completed_at` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_driver_deliveries`
--

/*!50001 DROP VIEW IF EXISTS `v_driver_deliveries`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_driver_deliveries` AS select `dt`.`branch_id` AS `branch_id`,cast(`s`.`completed_at` as date) AS `delivery_date`,`d`.`full_name` AS `driver_name`,`r`.`route_name` AS `route_name`,count(distinct `s`.`id`) AS `deliveries`,sum(`s`.`order_total`) AS `total_value`,sum((case when (`s`.`is_credit_sale` = 0) then `s`.`order_total` else 0 end)) AS `cash_value`,sum((case when (`s`.`is_credit_sale` = 1) then `s`.`order_total` else 0 end)) AS `credit_value` from ((((`sales` `s` join `dispatch_trip_sales` `dts` on((`dts`.`sale_id` = `s`.`id`))) join `dispatch_trips` `dt` on((`dts`.`trip_id` = `dt`.`id`))) join `drivers` `d` on((`dt`.`driver_id` = `d`.`id`))) left join `routes` `r` on((`s`.`route_id` = `r`.`id`))) where ((`s`.`status` = 'completed') and (`s`.`archived` = 0)) group by `dt`.`branch_id`,cast(`s`.`completed_at` as date),`d`.`full_name`,`r`.`route_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_eod_cashier_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_eod_cashier_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_eod_cashier_summary` AS select cast(`s`.`created_at` as date) AS `sale_date`,`s`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,`s`.`cashier_id` AS `cashier_id`,`u`.`username` AS `cashier`,count(distinct `s`.`id`) AS `total_transactions`,sum(`s`.`order_total`) AS `gross_sales`,sum(`s`.`total_vat`) AS `total_vat`,sum(`s`.`cash`) AS `cash_collected`,sum(`s`.`mpesa_amount`) AS `mpesa_collected`,sum(`s`.`equity_amount`) AS `equity_collected`,sum(`s`.`kcb_amount`) AS `kcb_collected`,(sum(`s`.`order_total`) - sum(`s`.`total_vat`)) AS `net_sales`,`tfs`.`working_amount` AS `opening_float`,`tfs`.`float_breakdown` AS `float_breakdown_json` from (((`sales` `s` join `branches` `b` on((`s`.`branch_id` = `b`.`id`))) join `users` `u` on((`s`.`cashier_id` = `u`.`id`))) left join `till_float_sessions` `tfs` on((`s`.`float_session_id` = `tfs`.`id`))) where ((`s`.`status` = 'completed') and (`s`.`archived` = 0)) group by cast(`s`.`created_at` as date),`s`.`branch_id`,`s`.`cashier_id`,`tfs`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_expenses_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_expenses_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_expenses_summary` AS select `e`.`expense_date` AS `expense_date`,`e`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,`eg`.`id` AS `expense_group_id`,`eg`.`group_name` AS `group_name`,count(0) AS `expense_count`,sum(`e`.`expense_amount`) AS `total_amount` from ((`expenses` `e` join `branches` `b` on((`e`.`branch_id` = `b`.`id`))) join `expense_groups` `eg` on((`e`.`expense_group_id` = `eg`.`id`))) where (`e`.`deleted_at` is null) group by `e`.`expense_date`,`e`.`branch_id`,`eg`.`id`,`eg`.`group_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_headcount_report`
--

/*!50001 DROP VIEW IF EXISTS `v_headcount_report`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_headcount_report` AS select `e`.`organization_id` AS `organization_id`,`e`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,`e`.`department_id` AS `department_id`,`d`.`department_name` AS `department_name`,`e`.`id` AS `employee_id`,`e`.`employee_code` AS `employee_code`,`e`.`full_name` AS `full_name`,`e`.`employment_status` AS `employment_status`,`e`.`employment_type` AS `employment_type`,`e`.`job_title` AS `job_title`,`e`.`hire_date` AS `hire_date`,`e`.`base_salary` AS `base_salary`,`e`.`is_active` AS `is_active` from ((`employees` `e` left join `departments` `d` on((`e`.`department_id` = `d`.`id`))) left join `branches` `b` on((`e`.`branch_id` = `b`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_hr_dashboard_kpi`
--

/*!50001 DROP VIEW IF EXISTS `v_hr_dashboard_kpi`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_hr_dashboard_kpi` AS select `o`.`id` AS `organization_id`,(select count(0) from `employees` `emp` where (`emp`.`organization_id` = `o`.`id`)) AS `total_employees`,(select count(0) from `employees` `emp` where ((`emp`.`organization_id` = `o`.`id`) and (`emp`.`is_active` = 1) and (`emp`.`employment_status` = 'active'))) AS `active_employees`,(select count(0) from `departments` `dep` where ((`dep`.`organization_id` = `o`.`id`) and (`dep`.`is_active` = 1))) AS `department_count`,(select coalesce(sum(`emp`.`base_salary`),0) from `employees` `emp` where ((`emp`.`organization_id` = `o`.`id`) and (`emp`.`is_active` = 1) and (`emp`.`employment_status` = 'active'))) AS `monthly_base_payroll`,(select count(0) from `employees` `emp` where ((`emp`.`organization_id` = `o`.`id`) and (`emp`.`contract_end_date` is not null) and (`emp`.`contract_end_date` <= (curdate() + interval 90 day)) and (`emp`.`employment_status` = 'active'))) AS `contracts_expiring_90d`,(select count(0) from `employees` `emp` where ((`emp`.`organization_id` = `o`.`id`) and (`emp`.`employment_status` in ('terminated','retired')))) AS `separated_employees`,(select count(0) from (`payroll_runs` `pr` join `pay_periods` `pp` on((`pr`.`pay_period_id` = `pp`.`id`))) where ((`pp`.`organization_id` = `o`.`id`) and (`pr`.`status` in ('processed','paid')))) AS `processed_payroll_runs` from `organizations` `o` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_invoice_payment_history`
--

/*!50001 DROP VIEW IF EXISTS `v_invoice_payment_history`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_invoice_payment_history` AS select `cip`.`id` AS `payment_id`,`cip`.`customer_num` AS `customer_num`,`c`.`customer_name` AS `customer_name`,`ci`.`invoice_number` AS `invoice_number`,`cip`.`date_paid` AS `date_paid`,`cip`.`amount_paid` AS `amount_paid`,`pm`.`method_name` AS `method_name`,`u`.`username` AS `received_by`,`cip`.`reference_number` AS `reference_number` from ((((`customer_invoice_payments` `cip` join `customers` `c` on((`cip`.`customer_num` = `c`.`customer_num`))) join `customer_invoices` `ci` on((`cip`.`customer_invoice_id` = `ci`.`id`))) join `payment_methods` `pm` on((`cip`.`payment_method_id` = `pm`.`id`))) join `users` `u` on((`cip`.`received_by` = `u`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_journal_register`
--

/*!50001 DROP VIEW IF EXISTS `v_journal_register`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_journal_register` AS select `je`.`id` AS `journal_entry_id`,`je`.`organization_id` AS `organization_id`,`je`.`branch_id` AS `branch_id`,`je`.`entry_number` AS `entry_number`,`je`.`entry_date` AS `entry_date`,`je`.`reference_type` AS `reference_type`,`je`.`reference_id` AS `reference_id`,`je`.`status` AS `status`,`je`.`description` AS `description`,sum(`jel`.`debit`) AS `total_debit`,sum(`jel`.`credit`) AS `total_credit`,`u`.`username` AS `created_by` from ((`journal_entries` `je` join `journal_entry_lines` `jel` on((`jel`.`journal_entry_id` = `je`.`id`))) join `users` `u` on((`je`.`created_by` = `u`.`id`))) group by `je`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_kra_receipts`
--

/*!50001 DROP VIEW IF EXISTS `v_kra_receipts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_kra_receipts` AS select cast(`kr`.`created_at` as date) AS `receipt_date`,`s`.`branch_id` AS `branch_id`,`s`.`channel` AS `channel`,`kr`.`status` AS `status`,count(0) AS `receipt_count`,sum(`s`.`order_total`) AS `order_total` from (`kra_responses` `kr` join `sales` `s` on((`kr`.`sale_id` = `s`.`id`))) group by cast(`kr`.`created_at` as date),`s`.`branch_id`,`s`.`channel`,`kr`.`status` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_low_stock`
--

/*!50001 DROP VIEW IF EXISTS `v_low_stock`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_low_stock` AS select `v_stock_on_hand`.`branch_id` AS `branch_id`,`v_stock_on_hand`.`product_code` AS `product_code`,`v_stock_on_hand`.`product_name` AS `product_name`,`v_stock_on_hand`.`wholesale_price` AS `wholesale_price`,`v_stock_on_hand`.`uom_name` AS `uom_name`,`v_stock_on_hand`.`conversion_factor` AS `conversion_factor`,`v_stock_on_hand`.`shop_quantity` AS `shop_quantity`,`v_stock_on_hand`.`store_quantity` AS `store_quantity`,`v_stock_on_hand`.`total_base_units` AS `total_base_units`,`v_stock_on_hand`.`reorder_point` AS `reorder_point`,`v_stock_on_hand`.`low_stock_alert_enabled` AS `low_stock_alert_enabled`,`v_stock_on_hand`.`product_alert` AS `product_alert`,`v_stock_on_hand`.`max_qty_measure` AS `max_qty_measure`,`v_stock_on_hand`.`markup_price` AS `markup_price`,`v_stock_on_hand`.`wholesale_markup_price` AS `wholesale_markup_price` from `v_stock_on_hand` where (`v_stock_on_hand`.`product_alert` = 'REORDER') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_open_lpo_lines`
--

/*!50001 DROP VIEW IF EXISTS `v_open_lpo_lines`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_open_lpo_lines` AS select `l`.`lpo_no` AS `lpo_no`,`l`.`supplier_id` AS `supplier_id`,`sup`.`supplier_name` AS `supplier_name`,`l`.`lpo_status_code` AS `lpo_status_code`,`ls`.`status_name` AS `status_name`,`l`.`due_date` AS `due_date`,`t`.`product_code` AS `product_code`,`p`.`product_name` AS `product_name`,`t`.`ordered_qty` AS `ordered_qty`,coalesce(`t`.`received_qty`,0) AS `received_qty`,(`t`.`ordered_qty` - coalesce(`t`.`received_qty`,0)) AS `pending_qty`,`t`.`cost_price` AS `cost_price`,`t`.`uom` AS `uom` from ((((`lpo_txn` `t` join `lpo_mst` `l` on((`t`.`lpo_no` = `l`.`lpo_no`))) join `suppliers` `sup` on((`l`.`supplier_id` = `sup`.`id`))) join `lpo_statuses` `ls` on((`l`.`lpo_status_code` = `ls`.`status_code`))) join `products` `p` on((`t`.`product_code` = `p`.`product_code`))) where ((`l`.`deleted_at` is null) and (`l`.`lpo_status_code` in (2,3)) and ((`t`.`ordered_qty` - coalesce(`t`.`received_qty`,0)) > 0.0001)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_payment_collection`
--

/*!50001 DROP VIEW IF EXISTS `v_payment_collection`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_payment_collection` AS select cast(`sp`.`paid_at` as date) AS `payment_date`,`s`.`branch_id` AS `branch_id`,`s`.`channel` AS `channel`,`pm`.`method_code` AS `method_code`,`pm`.`method_name` AS `method_name`,count(0) AS `payment_count`,sum(`sp`.`amount`) AS `total_collected` from ((`sale_payments` `sp` join `sales` `s` on((`sp`.`sale_id` = `s`.`id`))) join `payment_methods` `pm` on((`sp`.`payment_method_id` = `pm`.`id`))) where (`s`.`status` = 'completed') group by cast(`sp`.`paid_at` as date),`s`.`branch_id`,`s`.`channel`,`pm`.`method_code`,`pm`.`method_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_payroll_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_payroll_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_payroll_summary` AS select `pr`.`id` AS `payroll_run_id`,`pp`.`organization_id` AS `organization_id`,`pp`.`period_code` AS `period_code`,`pp`.`period_start` AS `period_start`,`pp`.`period_end` AS `period_end`,`pr`.`run_date` AS `run_date`,`pr`.`status` AS `status`,`pr`.`total_gross` AS `total_gross`,`pr`.`total_net` AS `total_net`,count(`pl`.`id`) AS `employee_count` from ((`payroll_runs` `pr` join `pay_periods` `pp` on((`pr`.`pay_period_id` = `pp`.`id`))) left join `payroll_lines` `pl` on((`pl`.`payroll_run_id` = `pr`.`id`))) group by `pr`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_pod_compliance`
--

/*!50001 DROP VIEW IF EXISTS `v_pod_compliance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_pod_compliance` AS select `pr`.`branch_id` AS `branch_id`,cast(`pr`.`captured_at` as date) AS `capture_date`,`r`.`route_name` AS `route_name`,`d`.`full_name` AS `driver_name`,count(`pr`.`id`) AS `pod_count`,sum((case when (`pr`.`status` = 'complete') then 1 else 0 end)) AS `complete_count`,sum((case when (`pr`.`status` = 'partial') then 1 else 0 end)) AS `partial_count`,sum((case when (`pr`.`status` = 'refused') then 1 else 0 end)) AS `refused_count` from ((((`pod_records` `pr` left join `sales` `s` on((`pr`.`sale_id` = `s`.`id`))) left join `routes` `r` on((`s`.`route_id` = `r`.`id`))) left join `dispatch_trips` `dt` on((`pr`.`trip_id` = `dt`.`id`))) left join `drivers` `d` on((`dt`.`driver_id` = `d`.`id`))) group by `pr`.`branch_id`,cast(`pr`.`captured_at` as date),`r`.`route_name`,`d`.`full_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_profit_loss_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_profit_loss_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_profit_loss_summary` AS select `sales_agg`.`period` AS `period`,`sales_agg`.`branch_id` AS `branch_id`,`sales_agg`.`branch_name` AS `branch_name`,`sales_agg`.`gross_revenue` AS `gross_revenue`,`sales_agg`.`vat_collected` AS `vat_collected`,`sales_agg`.`net_revenue` AS `net_revenue`,coalesce(`cogs`.`total_cost`,0) AS `cogs`,(`sales_agg`.`net_revenue` - coalesce(`cogs`.`total_cost`,0)) AS `gross_profit`,coalesce(`exp`.`total_expenses`,0) AS `total_expenses`,((`sales_agg`.`net_revenue` - coalesce(`cogs`.`total_cost`,0)) - coalesce(`exp`.`total_expenses`,0)) AS `net_profit` from (((select cast(`s`.`completed_at` as date) AS `period`,`s`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,sum(`s`.`order_total`) AS `gross_revenue`,sum(`s`.`total_vat`) AS `vat_collected`,(sum(`s`.`order_total`) - sum(`s`.`total_vat`)) AS `net_revenue` from (`sales` `s` join `branches` `b` on((`s`.`branch_id` = `b`.`id`))) where ((`s`.`status` = 'completed') and (`s`.`archived` = 0)) group by cast(`s`.`completed_at` as date),`s`.`branch_id`,`b`.`branch_name`) `sales_agg` left join (select cast(`sr`.`created_at` as date) AS `cost_date`,`sr`.`branch_id` AS `branch_id`,sum((`sr`.`units_received` * coalesce(`sr`.`cost_price`,0))) AS `total_cost` from `stock_receipts` `sr` group by cast(`sr`.`created_at` as date),`sr`.`branch_id`) `cogs` on(((`sales_agg`.`period` = `cogs`.`cost_date`) and (`sales_agg`.`branch_id` = `cogs`.`branch_id`)))) left join (select `expenses`.`expense_date` AS `expense_date`,`expenses`.`branch_id` AS `branch_id`,sum(`expenses`.`expense_amount`) AS `total_expenses` from `expenses` where (`expenses`.`deleted_at` is null) group by `expenses`.`expense_date`,`expenses`.`branch_id`) `exp` on(((`sales_agg`.`period` = `exp`.`expense_date`) and (`sales_agg`.`branch_id` = `exp`.`branch_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_purchases_by_supplier`
--

/*!50001 DROP VIEW IF EXISTS `v_purchases_by_supplier`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_purchases_by_supplier` AS select `s`.`id` AS `supplier_id`,`s`.`supplier_name` AS `supplier_name`,`l`.`lpo_no` AS `lpo_no`,`l`.`created_at` AS `order_date`,`l`.`due_date` AS `due_date`,`l`.`total_amount` AS `total_amount`,`l`.`lpo_status_code` AS `lpo_status_code`,`ls`.`status_name` AS `status_name`,count(`t`.`id`) AS `line_items`,sum(`t`.`ordered_qty`) AS `total_qty_ordered`,sum(`t`.`received_qty`) AS `total_qty_received` from (((`suppliers` `s` join `lpo_mst` `l` on((`l`.`supplier_id` = `s`.`id`))) join `lpo_statuses` `ls` on((`l`.`lpo_status_code` = `ls`.`status_code`))) join `lpo_txn` `t` on((`t`.`lpo_no` = `l`.`lpo_no`))) group by `s`.`id`,`l`.`lpo_no` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_route_loading_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_route_loading_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_route_loading_summary` AS select cast(coalesce(`s`.`delivery_date`,`s`.`created_at`) as date) AS `loading_date`,`r`.`route_name` AS `route_name`,`s`.`channel` AS `channel`,`s`.`cashier_id` AS `cashier_id`,`u`.`username` AS `salesperson`,count(distinct `s`.`id`) AS `total_orders`,count(`si`.`id`) AS `total_items`,sum(`si`.`quantity`) AS `total_qty`,sum(`si`.`amount`) AS `total_value`,sum(`s`.`order_total`) AS `grand_total`,sum((case when (`s`.`status` = 'completed') then `s`.`order_total` else 0 end)) AS `delivered_value`,sum((case when (`s`.`is_credit_sale` = 0) then `s`.`order_total` else 0 end)) AS `cash_collected`,sum((case when (`s`.`is_credit_sale` = 1) then `s`.`order_total` else 0 end)) AS `credit_outstanding` from (((`sales` `s` join `routes` `r` on((`s`.`route_id` = `r`.`id`))) join `users` `u` on((`s`.`cashier_id` = `u`.`id`))) join `sale_items` `si` on((`si`.`sale_id` = `s`.`id`))) where ((`s`.`route_id` is not null) and (`s`.`channel` in ('mobile','pos')) and (`s`.`archived` = 0)) group by cast(coalesce(`s`.`delivery_date`,`s`.`created_at`) as date),`s`.`route_id`,`s`.`cashier_id`,`s`.`channel` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_by_channel`
--

/*!50001 DROP VIEW IF EXISTS `v_sales_by_channel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_by_channel` AS select cast(`s`.`completed_at` as date) AS `sale_date`,`s`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,`s`.`channel` AS `channel`,`s`.`payment_status` AS `payment_status`,count(0) AS `order_count`,sum(`s`.`order_total`) AS `gross_sales`,sum(`s`.`amount_paid`) AS `collected`,sum(`s`.`total_vat`) AS `total_vat`,sum((`s`.`order_total` - `s`.`total_vat`)) AS `net_sales`,sum((case when (`s`.`is_credit_sale` = 1) then `s`.`order_total` else 0 end)) AS `credit_sales` from (`sales` `s` join `branches` `b` on((`s`.`branch_id` = `b`.`id`))) where ((`s`.`status` = 'completed') and (`s`.`archived` = 0)) group by cast(`s`.`completed_at` as date),`s`.`branch_id`,`s`.`channel`,`s`.`payment_status` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_by_customer`
--

/*!50001 DROP VIEW IF EXISTS `v_sales_by_customer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_by_customer` AS select `c`.`customer_num` AS `customer_num`,`c`.`customer_name` AS `customer_name`,`c`.`phone_number` AS `phone_number`,`r`.`route_name` AS `route_name`,count(distinct `s`.`id`) AS `total_orders`,sum(`s`.`order_total`) AS `total_purchased`,coalesce(sum(`ci`.`invoice_total`),0) AS `total_invoiced`,coalesce(sum(`ci`.`amount_paid`),0) AS `total_paid`,coalesce(sum(`ci`.`balance_due`),0) AS `total_outstanding`,`c`.`current_balance` AS `ar_balance` from (((`customers` `c` left join `sales` `s` on(((`s`.`customer_num` = `c`.`customer_num`) and (`s`.`status` = 'completed')))) left join `routes` `r` on((`c`.`route_id` = `r`.`id`))) left join `customer_invoices` `ci` on(((`ci`.`customer_num` = `c`.`customer_num`) and (`ci`.`deleted_at` is null)))) where (`c`.`deleted_at` is null) group by `c`.`customer_num` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_by_product`
--

/*!50001 DROP VIEW IF EXISTS `v_sales_by_product`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_by_product` AS select `si`.`product_code` AS `product_code`,`p`.`product_name` AS `product_name`,cast(`s`.`created_at` as date) AS `sale_date`,`s`.`branch_id` AS `branch_id`,`s`.`channel` AS `channel`,sum(`si`.`quantity`) AS `qty_sold`,`si`.`uom` AS `sell_uom`,sum(`si`.`amount`) AS `total_revenue`,sum(`si`.`product_vat`) AS `total_vat`,sum(`si`.`discount_given`) AS `total_discount` from ((`sale_items` `si` join `sales` `s` on((`si`.`sale_id` = `s`.`id`))) join `products` `p` on((`si`.`product_code` = `p`.`product_code`))) where (`s`.`status` = 'completed') group by `si`.`product_code`,cast(`s`.`created_at` as date),`s`.`branch_id`,`s`.`channel`,`si`.`uom` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_by_user`
--

/*!50001 DROP VIEW IF EXISTS `v_sales_by_user`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_by_user` AS select cast(`s`.`completed_at` as date) AS `sale_date`,`s`.`branch_id` AS `branch_id`,`s`.`cashier_id` AS `cashier_id`,`u`.`full_name` AS `salesperson`,`s`.`channel` AS `channel`,count(distinct `s`.`id`) AS `order_count`,sum(`s`.`order_total`) AS `gross_sales`,sum(`s`.`amount_paid`) AS `amount_collected` from (`sales` `s` join `users` `u` on((`s`.`cashier_id` = `u`.`id`))) where (`s`.`status` = 'completed') group by cast(`s`.`completed_at` as date),`s`.`branch_id`,`s`.`cashier_id`,`s`.`channel` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_pipeline`
--

/*!50001 DROP VIEW IF EXISTS `v_sales_pipeline`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_pipeline` AS select cast(`s`.`created_at` as date) AS `order_date`,`s`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,`s`.`channel` AS `channel`,`s`.`status` AS `status`,`s`.`payment_status` AS `payment_status`,count(0) AS `order_count`,sum(`s`.`order_total`) AS `pipeline_value`,sum(`s`.`amount_paid`) AS `collected_so_far` from (`sales` `s` join `branches` `b` on((`s`.`branch_id` = `b`.`id`))) where ((`s`.`status` not in ('completed','cancelled')) and (`s`.`archived` = 0)) group by cast(`s`.`created_at` as date),`s`.`branch_id`,`s`.`channel`,`s`.`status`,`s`.`payment_status` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_staff_turnover`
--

/*!50001 DROP VIEW IF EXISTS `v_staff_turnover`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_staff_turnover` AS select `e`.`organization_id` AS `organization_id`,`e`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,`e`.`department_id` AS `department_id`,`d`.`department_name` AS `department_name`,sum((case when ((`e`.`employment_status` = 'active') and (`e`.`is_active` = 1)) then 1 else 0 end)) AS `active_employees`,sum((case when (`e`.`employment_status` in ('terminated','retired')) then 1 else 0 end)) AS `separated_employees`,count(0) AS `total_employees`,round(((100.0 * sum((case when (`e`.`employment_status` in ('terminated','retired')) then 1 else 0 end))) / nullif(count(0),0)),2) AS `turnover_rate_pct` from ((`employees` `e` left join `departments` `d` on((`e`.`department_id` = `d`.`id`))) left join `branches` `b` on((`e`.`branch_id` = `b`.`id`))) group by `e`.`organization_id`,`e`.`branch_id`,`b`.`branch_name`,`e`.`department_id`,`d`.`department_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_statutory_deductions`
--

/*!50001 DROP VIEW IF EXISTS `v_statutory_deductions`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_statutory_deductions` AS select `e`.`organization_id` AS `organization_id`,`e`.`branch_id` AS `branch_id`,`pr`.`id` AS `payroll_run_id`,`pp`.`period_code` AS `period_code`,`pp`.`period_start` AS `period_start`,`pp`.`period_end` AS `period_end`,`pr`.`run_date` AS `run_date`,`pr`.`status` AS `payroll_status`,`e`.`id` AS `employee_id`,`e`.`employee_code` AS `employee_code`,`e`.`full_name` AS `full_name`,`d`.`department_name` AS `department_name`,`pl`.`gross_pay` AS `gross_pay`,`pl`.`taxable_income` AS `taxable_income`,`pl`.`nssf` AS `nssf`,`pl`.`shif` AS `shif`,`pl`.`housing_levy` AS `housing_levy`,`pl`.`paye` AS `paye`,`pl`.`other_deductions` AS `other_deductions`,`pl`.`deductions` AS `total_deductions`,`pl`.`net_pay` AS `net_pay`,`pl`.`employer_nssf` AS `employer_nssf`,`pl`.`employer_housing` AS `employer_housing` from ((((`payroll_lines` `pl` join `payroll_runs` `pr` on((`pl`.`payroll_run_id` = `pr`.`id`))) join `pay_periods` `pp` on((`pr`.`pay_period_id` = `pp`.`id`))) join `employees` `e` on((`pl`.`employee_id` = `e`.`id`))) left join `departments` `d` on((`e`.`department_id` = `d`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_stock_chain`
--

/*!50001 DROP VIEW IF EXISTS `v_stock_chain`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_stock_chain` AS select `it`.`branch_id` AS `branch_id`,`it`.`product_code` AS `product_code`,`p`.`product_name` AS `product_name`,min((case when (`it`.`transaction_type` = 'PURCHASE') then `it`.`created_at` end)) AS `first_received_at`,min((case when (`it`.`transaction_type` in ('POS_SALE','MOBILE_SALE','BACKEND_SALE')) then `it`.`created_at` end)) AS `first_sold_at`,max(`it`.`created_at`) AS `last_movement_at`,sum((case when ((`it`.`transaction_type` = 'PURCHASE') and (`it`.`quantity_change` > 0)) then `it`.`quantity_change` else 0 end)) AS `total_received`,sum((case when (`it`.`transaction_type` in ('POS_SALE','MOBILE_SALE','BACKEND_SALE')) then abs(`it`.`quantity_change`) else 0 end)) AS `total_sold`,`cs`.`shop_quantity` AS `current_shop_stock`,`cs`.`store_quantity` AS `current_store_stock` from ((`inventory_transactions` `it` join `products` `p` on((`it`.`product_code` = `p`.`product_code`))) left join `current_stock` `cs` on(((`cs`.`product_code` = `it`.`product_code`) and (`cs`.`branch_id` = `it`.`branch_id`)))) group by `it`.`branch_id`,`it`.`product_code`,`p`.`product_name`,`cs`.`shop_quantity`,`cs`.`store_quantity` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_stock_on_hand`
--

/*!50001 DROP VIEW IF EXISTS `v_stock_on_hand`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_stock_on_hand` AS select `cs`.`branch_id` AS `branch_id`,`p`.`product_code` AS `product_code`,`p`.`product_name` AS `product_name`,`p`.`unit_price` AS `wholesale_price`,`u`.`full_name` AS `uom_name`,`u`.`conversion_factor` AS `conversion_factor`,`cs`.`shop_quantity` AS `shop_quantity`,`cs`.`store_quantity` AS `store_quantity`,(`cs`.`shop_quantity` + `cs`.`store_quantity`) AS `total_base_units`,`p`.`reorder_point` AS `reorder_point`,`p`.`low_stock_alert_enabled` AS `low_stock_alert_enabled`,(case when ((`cs`.`shop_quantity` + `cs`.`store_quantity`) <= `p`.`reorder_point`) then 'REORDER' else 'OK' end) AS `product_alert`,`rps`.`max_qty_measure` AS `max_qty_measure`,`rps`.`markup_price` AS `markup_price`,`rps`.`wholesale_markup_price` AS `wholesale_markup_price` from (((`current_stock` `cs` join `products` `p` on((`cs`.`product_code` = `p`.`product_code`))) join `uoms` `u` on((`p`.`unit_id` = `u`.`id`))) left join `retail_package_settings` `rps` on((`p`.`product_code` = `rps`.`product_code`))) where (`p`.`deleted_at` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_stock_receipts_detail`
--

/*!50001 DROP VIEW IF EXISTS `v_stock_receipts_detail`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_stock_receipts_detail` AS select cast(`sr`.`created_at` as date) AS `receipt_date`,`sr`.`branch_id` AS `branch_id`,`sr`.`organization_id` AS `organization_id`,`sr`.`product_code` AS `product_code`,`p`.`product_name` AS `product_name`,`sr`.`units_received` AS `units_received`,`sr`.`stock_location` AS `stock_location`,`sr`.`cost_price` AS `cost_price`,(`sr`.`units_received` * coalesce(`sr`.`cost_price`,0)) AS `line_cost`,`sr`.`invoice_number` AS `invoice_number`,`u`.`username` AS `received_by` from ((`stock_receipts` `sr` join `products` `p` on((`sr`.`product_code` = `p`.`product_code`))) join `users` `u` on((`sr`.`received_by` = `u`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_stock_reservations_active`
--

/*!50001 DROP VIEW IF EXISTS `v_stock_reservations_active`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_stock_reservations_active` AS select `sr`.`branch_id` AS `branch_id`,`sr`.`product_code` AS `product_code`,`p`.`product_name` AS `product_name`,`sr`.`stock_location` AS `stock_location`,sum(`sr`.`quantity`) AS `reserved_qty`,count(0) AS `reservation_count` from (`stock_reservations` `sr` join `products` `p` on((`sr`.`product_code` = `p`.`product_code`))) where (`sr`.`released_at` is null) group by `sr`.`branch_id`,`sr`.`product_code`,`p`.`product_name`,`sr`.`stock_location` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_stock_transfers`
--

/*!50001 DROP VIEW IF EXISTS `v_stock_transfers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_stock_transfers` AS select cast(`smh`.`created_at` as date) AS `transfer_date`,`smh`.`branch_id` AS `branch_id`,`smh`.`product_code` AS `product_code`,`p`.`product_name` AS `product_name`,`smh`.`from_location` AS `from_location`,`smh`.`to_location` AS `to_location`,sum(`smh`.`quantity_moved`) AS `total_moved`,count(0) AS `transfer_count` from (`stock_movement_history` `smh` join `products` `p` on((`smh`.`product_code` = `p`.`product_code`))) group by cast(`smh`.`created_at` as date),`smh`.`branch_id`,`smh`.`product_code`,`smh`.`from_location`,`smh`.`to_location` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_stock_valuation`
--

/*!50001 DROP VIEW IF EXISTS `v_stock_valuation`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_stock_valuation` AS select `cs`.`branch_id` AS `branch_id`,`p`.`product_code` AS `product_code`,`p`.`product_name` AS `product_name`,`cs`.`shop_quantity` AS `shop_quantity`,`cs`.`store_quantity` AS `store_quantity`,(`cs`.`shop_quantity` + `cs`.`store_quantity`) AS `total_qty`,`p`.`last_cost_price` AS `last_cost_price`,`p`.`unit_price` AS `unit_price`,((`cs`.`shop_quantity` + `cs`.`store_quantity`) * coalesce(`p`.`last_cost_price`,0)) AS `cost_value`,((`cs`.`shop_quantity` + `cs`.`store_quantity`) * `p`.`unit_price`) AS `retail_value` from (`current_stock` `cs` join `products` `p` on((`cs`.`product_code` = `p`.`product_code`))) where (`p`.`deleted_at` is null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_supplier_payables`
--

/*!50001 DROP VIEW IF EXISTS `v_supplier_payables`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_supplier_payables` AS select `s`.`id` AS `supplier_id`,`s`.`supplier_code` AS `supplier_code`,`s`.`supplier_name` AS `supplier_name`,coalesce(`rec`.`received_value`,0) AS `received_value`,coalesce(`ret`.`return_value`,0) AS `return_value`,greatest((coalesce(`rec`.`received_value`,0) - coalesce(`ret`.`return_value`,0)),0) AS `balance_due`,coalesce(`rec`.`open_lpo_count`,0) AS `open_lpo_count` from ((`suppliers` `s` left join (select `l`.`supplier_id` AS `supplier_id`,sum((coalesce(`t`.`received_qty`,0) * coalesce(`t`.`cost_price`,0))) AS `received_value`,count(distinct `l`.`lpo_no`) AS `open_lpo_count` from (`lpo_txn` `t` join `lpo_mst` `l` on((`l`.`lpo_no` = `t`.`lpo_no`))) where (coalesce(`t`.`received_qty`,0) > 0) group by `l`.`supplier_id`) `rec` on((`rec`.`supplier_id` = `s`.`id`))) left join (select `sr`.`supplier_id` AS `supplier_id`,sum((`sr`.`quantity` * coalesce(`p`.`unit_price`,0))) AS `return_value` from (`supplier_returns` `sr` join `products` `p` on((`p`.`product_code` = `sr`.`product_code`))) group by `sr`.`supplier_id`) `ret` on((`ret`.`supplier_id` = `s`.`id`))) where (greatest((coalesce(`rec`.`received_value`,0) - coalesce(`ret`.`return_value`,0)),0) > 0) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_supplier_returns_detail`
--

/*!50001 DROP VIEW IF EXISTS `v_supplier_returns_detail`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_supplier_returns_detail` AS select cast(`sr`.`created_at` as date) AS `return_date`,`sr`.`branch_id` AS `branch_id`,`sr`.`supplier_id` AS `supplier_id`,`s`.`supplier_name` AS `supplier_name`,`sr`.`product_code` AS `product_code`,`p`.`product_name` AS `product_name`,`sr`.`quantity` AS `quantity`,`sr`.`stock_location` AS `stock_location`,`sr`.`reason` AS `reason`,`u`.`username` AS `returned_by` from (((`supplier_returns` `sr` join `suppliers` `s` on((`sr`.`supplier_id` = `s`.`id`))) join `products` `p` on((`sr`.`product_code` = `p`.`product_code`))) join `users` `u` on((`sr`.`returned_by` = `u`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_till_session_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_till_session_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_till_session_summary` AS select `tfs`.`id` AS `session_id`,`tfs`.`session_date` AS `session_date`,`tfs`.`branch_id` AS `branch_id`,`tfs`.`till_id` AS `till_id`,`t`.`till_number` AS `till_number`,`tfs`.`cashier_id` AS `cashier_id`,`u`.`username` AS `cashier`,`tfs`.`status` AS `status`,`tfs`.`working_amount` AS `opening_float`,`tfs`.`closing_amount` AS `closing_amount`,`tfs`.`expected_amount` AS `expected_amount`,`tfs`.`cash_sales` AS `cash_sales`,coalesce(`s`.`txn_count`,0) AS `completed_sales`,coalesce(`s`.`gross`,0) AS `gross_sales` from (((`till_float_sessions` `tfs` join `tills` `t` on((`tfs`.`till_id` = `t`.`id`))) join `users` `u` on((`tfs`.`cashier_id` = `u`.`id`))) left join (select `sales`.`float_session_id` AS `float_session_id`,count(0) AS `txn_count`,sum(`sales`.`order_total`) AS `gross` from `sales` where (`sales`.`status` = 'completed') group by `sales`.`float_session_id`) `s` on((`s`.`float_session_id` = `tfs`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_top_debtors`
--

/*!50001 DROP VIEW IF EXISTS `v_top_debtors`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_top_debtors` AS select `c`.`customer_num` AS `customer_num`,`c`.`customer_name` AS `customer_name`,`c`.`phone_number` AS `phone_number`,`r`.`route_name` AS `route_name`,`c`.`current_balance` AS `current_balance`,count(distinct `ci`.`id`) AS `open_invoices`,coalesce(sum(`ci`.`balance_due`),0) AS `invoice_balance` from ((`customers` `c` left join `routes` `r` on((`c`.`route_id` = `r`.`id`))) left join `customer_invoices` `ci` on(((`ci`.`customer_num` = `c`.`customer_num`) and (`ci`.`payment_status` in (0,1)) and (`ci`.`deleted_at` is null)))) where ((`c`.`deleted_at` is null) and ((`c`.`current_balance` > 0) or (`ci`.`id` is not null))) group by `c`.`customer_num` having ((`c`.`current_balance` > 0) or (coalesce(sum(`ci`.`balance_due`),0) > 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_trip_cash_settlement`
--

/*!50001 DROP VIEW IF EXISTS `v_trip_cash_settlement`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_trip_cash_settlement` AS select `dt`.`branch_id` AS `branch_id`,`dt`.`scheduled_date` AS `scheduled_date`,`dt`.`trip_code` AS `trip_code`,`r`.`route_name` AS `route_name`,`d`.`full_name` AS `driver_name`,`dt`.`expected_cash` AS `expected_cash`,`dt`.`collected_cash` AS `collected_cash`,`dt`.`cash_variance` AS `cash_variance`,`dt`.`status` AS `status`,`dt`.`settled_at` AS `settled_at`,`su`.`username` AS `settled_by` from (((`dispatch_trips` `dt` left join `routes` `r` on((`dt`.`route_id` = `r`.`id`))) left join `drivers` `d` on((`dt`.`driver_id` = `d`.`id`))) left join `users` `su` on((`dt`.`settled_by` = `su`.`id`))) where ((`dt`.`status` in ('completed','in_transit')) or (`dt`.`settled_at` is not null) or (`dt`.`collected_cash` is not null)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_vat_collected`
--

/*!50001 DROP VIEW IF EXISTS `v_vat_collected`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`steve`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_vat_collected` AS select cast(`s`.`completed_at` as date) AS `sale_date`,`s`.`branch_id` AS `branch_id`,`b`.`branch_name` AS `branch_name`,`s`.`channel` AS `channel`,sum(`s`.`total_vat`) AS `vat_collected`,sum(`s`.`order_total`) AS `gross_sales`,count(0) AS `orders` from (`sales` `s` join `branches` `b` on((`s`.`branch_id` = `b`.`id`))) where ((`s`.`status` = 'completed') and (`s`.`archived` = 0)) group by cast(`s`.`completed_at` as date),`s`.`branch_id`,`s`.`channel` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-20 20:29:33
